/*******************************************************************************
 * Copyright (c) 2002, 2004 eclipse-ccase.sourceforge.net.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Matthew Conway - initial API and implementation
 *     IBM Corporation - concepts and ideas from Eclipse
 *     Gunnar Wagenknecht - new features, enhancements and bug fixes
 *******************************************************************************/
package net.sourceforge.clearcase.simple;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 * ClearcaseCLI.
 */
public class ClearcaseCLI implements IClearcase {

    private String newLine = System.getProperty("line.separator");

    private String prompt = "Usage: pwd" + newLine;

    Process cleartool;

    private BufferedReader stdout;

    private BufferedReader stderr;

    private Writer stdin;

    private char[] buf = new char[4096];

    ClearcaseCLI() throws IOException {
        validateProcess();
    }

    public void destroy() {
        if (isRunning()) {
            cleartool.destroy();

            if (null != debugger)
                    debugger.debugClearcase("ClearCaseCLI",
                            "[cleartool]: destroyed");
        }
    }

    private boolean isRunning() {
        boolean running = false;
        if (cleartool != null) {
            try {
                cleartool.exitValue();
            } catch (IllegalThreadStateException ex) {
                running = true;
            }
        }
        return running;
    }

    private void validateProcess() throws IOException {
        if (!isRunning()) {
            // Only want to add shutdown hook once per process, and
            // cleartool is only ever null first time through
            if (cleartool == null) {
                Runtime.getRuntime().addShutdownHook(new Thread() {

                    public void run() {
                        try {
                            if (cleartool != null) {
                                cleartool.destroy();

                                if (null != debugger)
                                        debugger.debugClearcase("ClearCaseCLI",
                                                "[cleartool]: destroyed");
                            }
                        } catch (Exception ex) {
                            // ok
                        }
                    }
                });
            }
            cleartool = Runtime.getRuntime().exec("cleartool");
            stdout = new BufferedReader(new InputStreamReader(
                    new BufferedInputStream(cleartool.getInputStream())));
            stderr = new BufferedReader(new InputStreamReader(
                    new BufferedInputStream(cleartool.getErrorStream())));
            stdin = new OutputStreamWriter(cleartool.getOutputStream());

            if (null != debugger)
                    debugger.debugClearcase("ClearCaseCLI",
                            "[cleartool]: initialized process");
        }
    }

    private synchronized Status execute(final String cmd) {
        if (null != debugger)
                debugger.debugClearcase("ClearCaseCLI", "[execute]: " + cmd);

        try {
            validateProcess();
            stdin.write(cmd);
            stdin.write(newLine);
            stdin.write("pwd -h");
            stdin.write(newLine);
            stdin.flush();

            return readOutput();
        } catch (Exception ex) {
            if (null != debugger)
                    debugger.debugClearcase("ClearCaseCLI", "[error]: "
                            + ex.getLocalizedMessage());

            return new Status(false,
                    "Could not execute command due to unexpected exception: "
                            + ex);
        }
    }

    private Status readOutput() {
        int count = 0;
        StringBuffer out = new StringBuffer();
        StringBuffer err = new StringBuffer();
        StringBuffer msg = new StringBuffer();
        boolean status = true;

        try {
            while (true) {
                try {
                    int sleeping = 1000;
                    while (!stdout.ready() && sleeping > 0) {
                        Thread.sleep(10);
                        sleeping = -10;
                    }
                } catch (InterruptedException e) {
                    // ok
                }

                // block on read of stdout as we always expect at least the
                // prompt
                count = stdout.read(buf);
                out.append(buf, 0, count);

                if (stderr.ready()) {
                    count = stderr.read(buf);
                    err.append(buf, 0, count);
                }

                // Exit when we get the prompt as its always the last thing
                // done,
                // so we know cmd has finished
                if (out.toString().endsWith(prompt)) {
                    out.delete(out.length() - prompt.length(), out.length());
                    status = true;
                    break;
                }
            }
        } catch (IOException ex) {
            throw new RuntimeException(
                    "IOException while trying to parse cleartool output: " + ex);
        }

        if (out.length() > 0) {
            msg.append(out.toString());
        }
        if (err.length() > 0) {
            if (null != debugger)
                    debugger.debugClearcase("ClearCaseCLI",
                            "[cleartool error]: " + err.toString());

            msg.append(err.toString());
            status = false;
        }

        return new Status(status, msg.toString());
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#add(java.lang.String,
     *      java.lang.String, boolean, boolean)
     */
    public Status add(String file, String comment, boolean isDirectory,
            boolean makeMaster) {
        String masterFlag = makeMaster ? "-master " : "";
        if (isDirectory)
            return execute("mkdir "
                    + getArgumentWithComment(comment, masterFlag
                            + ClearcaseUtil.quote(file)));

        else
            return execute("mkelem "
                    + getArgumentWithComment(comment, masterFlag
                            + ClearcaseUtil.quote(file)));

    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#checkin(String, String,
     *      boolean)
     */
    public Status checkin(String file, String comment, boolean ptime) {
        if (isSymbolicLink(file)) {
            String oldFile = file;
            file = getResolvedLinkTarget(file);
            if (null == file)
                    return new Status(false, "Invalid link target: " + oldFile);
        }

        String ptimeFlag = ptime ? "-ptime " : "";
        return execute("checkin -identical "
                + getArgumentWithComment(comment, ptimeFlag
                        + ClearcaseUtil.quote(file)));
    }

    /**
     * Returns the argument with comment for the cleartool command.
     * <p>
     * If the comment includes new lines or double quotes, the cleartool is
     * forced to query the comment interactively.
     * 
     * @param comment
     * @param argument
     * @return the argument with comment
     */
    private final String getArgumentWithComment(String comment, String argument) {
        if (comment.indexOf(newLine) != -1 || comment.indexOf('"') != -1) {
            // pay attantion ^Z and NEWLINE + "." + NEWLINE are termination
            // chars

            // the comment is not allowed to contain CRTL+Z (^Z)
            int index = comment.indexOf(26);
            while (index != -1) {
                comment = comment.substring(0, index)
                        + comment.substring(index + 1);
                index = comment.indexOf(26);
            }

            // the comment is not allowed to contain NEWLINE + . + NEWLINE
            index = comment.indexOf(newLine + "." + newLine);
            while (index != -1) {
                comment = comment.substring(0, index)
                        + comment.substring(index + 1);
                index = comment.indexOf(newLine + "." + newLine);
            }

            // use line and double quote safe interactive cleartool operation
            return argument + newLine + comment + newLine + "." + newLine;
        }
        return "-c " + ClearcaseUtil.quote(comment) + " " + argument;
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#checkout(java.lang.String,
     *      java.lang.String, boolean, boolean, boolean, boolean)
     */
    public Status checkout(String file, String comment, boolean reserved,
            boolean ptime) {
        if (isSymbolicLink(file)) {
            String oldFile = file;
            file = getResolvedLinkTarget(file);
            if (null == file)
                    return new Status(false, "Invalid link target: " + oldFile);
        }

        long lastModified = new File(file).lastModified();
        String ptimeFlag = ptime ? "-ptime " : "";
        String resFlag = reserved ? "-reserved " : "-unreserved ";
        Status status = execute("checkout "
                + getArgumentWithComment(comment, ptimeFlag + resFlag
                        + ClearcaseUtil.quote(file)));
        if (status.status) {
            // fix file modification time
            if (ptime && lastModified > 0L) {
                File fileObj = new File(file);
                if (lastModified != fileObj.lastModified()) {
                    fileObj.setLastModified(lastModified);
                    System.out.println("!!! manual setting modification time !!!");
                }
            }
        }

        return status;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#cleartool(String)
     */
    public Status cleartool(String cmd) {
        return execute(cmd);
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#delete(String, String)
     */
    public Status delete(String file, String comment) {
        if (isSymbolicLink(file)) { return new Status(false,
                "Cannot delete link: " + file); }

        return execute("rmname "
                + getArgumentWithComment(comment, ClearcaseUtil.quote(file)));

    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#getViewName(String)
     */
    public Status getViewName(String file) {
        File dir = new File(file);
        if (!dir.isDirectory()) dir = dir.getParentFile();
        synchronized (this) {
            Status result = execute("cd " + ClearcaseUtil.quote(dir.getPath()));
            if (result.status) result = execute("pwv -s");
            return result;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#getViewRoot(java.lang.String)
     */
    public Status getViewRoot(String file) {
        File dir = new File(file);
        if (!dir.isDirectory()) dir = dir.getParentFile();
        synchronized (this) {
            Status result = execute("cd " + ClearcaseUtil.quote(dir.getPath()));
            if (result.status) result = execute("pwv -root");
            return result;
        }
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isCheckedOut(String,
     *      boolean)
     */
    public boolean isCheckedOut(String file, boolean isSymbolicLink) {
        if (isSymbolicLink) {
            file = getResolvedLinkTarget(file);
            if (null == file) return false;
        }

        Status ret = execute("describe -fmt " + ClearcaseUtil.quote("%f") + " "
                + ClearcaseUtil.quote(file));
        if (ret.status && ret.message.trim().length() > 0)
            return true;
        else
            return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#isCheckedOutInAnotherView(java.lang.String,boolean)
     */
    public boolean isCheckedOutInAnotherView(String file, boolean isSymbolicLink) {
        if (isSymbolicLink) {
            file = getResolvedLinkTarget(file);
            if (null == file) return false;
        }

        Status status = getViewName(file);
        if (status.status && status.message.trim().length() > 0) {
            String currentView = status.message.trim();
            status = execute("lsco -d -fmt " + ClearcaseUtil.quote("%Tf") + " "
                    + ClearcaseUtil.quote(file));
            if (status.status && status.message.trim().length() > 0
                    && !currentView.equals(status.message.trim())) return true;
        }
        return false;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isDifferent(String)
     */
    public boolean isDifferent(String file) {
        boolean isSymbolicLink = isSymbolicLink(file);
        if (isSymbolicLink) {
            file = getResolvedLinkTarget(file);
            if (null == file) return false;
        }

        boolean result = false;

        if (isCheckedOut(file, isSymbolicLink)) {
            Status diffResult = execute("diff -pred "
                    + ClearcaseUtil.quote(file));
            if (!diffResult.message.startsWith("Files are identical"))
                    result = true;
        }
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isElement(String)
     */
    public boolean isElement(String file) {
        Status ret = execute("describe -fmt " + ClearcaseUtil.quote("%Vn")
                + " " + ClearcaseUtil.quote(file));
        if (ret.status && ret.message.trim().length() > 0)
            return true;
        else if (ret.status) {
            // we may have a link
            return isSymbolicLink(file);
        }

        return false;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isHijacked(String,boolean)
     */
    public boolean isHijacked(String file, boolean isSymbolicLink) {
        if (isSymbolicLink) {
            file = getResolvedLinkTarget(file);
            if (null == file) return false;
        }

        boolean result = false;
        Status lsResult = execute("ls " + ClearcaseUtil.quote(file));
        if (lsResult.status && lsResult.message.indexOf("[hijacked]") != -1)
                result = true;
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isSnapShot(String,boolean)
     */
    public boolean isSnapShot(String file, boolean isSymbolicLink) {
        if (isSymbolicLink) {
            file = getResolvedLinkTarget(file);
            if (null == file) return false;
        }

        File dir = new File(file);
        if (!dir.isDirectory()) dir = dir.getParentFile();
        synchronized (this) {
            Status result = execute("cd " + dir.getPath());
            if (result.status)
                    result = execute("lsview -cview -properties -full");
            if (result.status
                    && result.message.indexOf("Properties: snapshot") != -1)
                return true;
            else
                return false;
        }
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#move(String, String, String)
     */
    public Status move(String file, String newfile, String comment) {
        if (isSymbolicLink(file)) { return new Status(false,
                "Cannot delete link: " + file); }

        return execute("move "
                + getArgumentWithComment(comment, ClearcaseUtil.quote(file)
                        + " " + ClearcaseUtil.quote(newfile)));
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#uncheckout(String, boolean)
     */
    public Status uncheckout(String file, boolean keep) {
        if (isSymbolicLink(file)) {
            String oldFile = file;
            file = getResolvedLinkTarget(file);
            if (null == file)
                    return new Status(false, "Invalid link target: " + oldFile);
        }

        String flag = keep ? "-keep " : "-rm ";
        return execute("uncheckout " + flag + ClearcaseUtil.quote(file));
    }

    IClearcaseDebugger debugger;

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#setDebugger(net.sourceforge.clearcase.simple.IClearcaseDebugger)
     */
    public void setDebugger(IClearcaseDebugger debugger) {
        this.debugger = debugger;
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#isSymbolicLink(java.lang.String)
     */
    public boolean isSymbolicLink(String file) {
        try {
            Status status = execute("describe -fmt \"%m\" "
                    + ClearcaseUtil.quote(file));
            if (status.status && status.message.indexOf("symbolic link") >= 0)
                    return true;
        } catch (Exception ex) {
            // ignore
        }
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#getSymbolicLinkTarget(java.lang.String)
     */
    public Status getSymbolicLinkTarget(String file) {
        return cleartool("describe -fmt \"%[slink_text]p\" "
                + ClearcaseUtil.quote(file));
    }

    /**
     * @param file
     * @return
     */
    private String getResolvedLinkTarget(String file) {
        Status status = getSymbolicLinkTarget(file);
        if (status.status) {
            File target = new File(status.message);
            if (target.isAbsolute())
                    return target.exists() ? target.getAbsolutePath() : null;

            // target is relative to source
            File parent = new File(file).getParentFile();
            if (null == parent) return null;
            target = new File(parent, status.message);
            return target.exists() ? target.getAbsolutePath() : null;
        }
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#isSymbolicLinkTargetValid(java.lang.String)
     */
    public boolean isSymbolicLinkTargetValid(String file) {
        /*
         * A link target is valid if it exists in the file system. That means
         * that Clearcase could resolve it.
         */
        return new File(file).exists() || null != getResolvedLinkTarget(file);
    }
}