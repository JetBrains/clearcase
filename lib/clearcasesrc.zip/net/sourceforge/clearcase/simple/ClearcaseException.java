package net.sourceforge.clearcase.simple;

public class ClearcaseException extends Exception
{

	public ClearcaseException()
	{
		super();
	}

	public ClearcaseException(String message)
	{
		super(message);
	}

}
