package net.sourceforge.clearcase.simple;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public class ClearcaseDummy implements IClearcase
{
	private static final String SAVE_FILE_NAME = "clearcasedummy"; //$NON-NLS-1$

	private static final int info = 1;
	private static final int err = 2;

	private Map eltMap = new HashMap();

	static class Element implements Serializable
	{
		boolean isElt = true;
		boolean checkedOut = false;
	}

	ClearcaseDummy()
	{
		super();
		load(new File(SAVE_FILE_NAME));
	}

	private void log(int status, String msg, Throwable t)
	{
		PrintStream out;
		if (status == err)
			out = System.err;
		else
			out = System.out;
		if (t != null)
			msg += ": " + t; //$NON-NLS-1$
		out.println("ClearcaseDummy: " + msg); //$NON-NLS-1$
	}

	private Element getElt(String file)
	{
		if (!isElt(file))
			throw new IllegalArgumentException("Not an element"); //$NON-NLS-1$
		return (Element) eltMap.get(file);
	}

	private boolean isElt(String file)
	{
		return eltMap.containsKey(file);
	}

	private void makeElt(String file)
	{
		Element elt = new Element();
		elt.checkedOut = true;
		eltMap.put(file, elt);
	}

	private void removeElt(String file)
	{
		eltMap.remove(file);
	}

	
    /* (non-Javadoc)
     * @see net.sourceforge.clearcase.simple.IClearcase#checkout(java.lang.String, java.lang.String, boolean, boolean, boolean, boolean)
     */
    public Status checkout(String file, String comment, boolean reserved,
            boolean ptime) {
        String msg =
            "Checkout: '" //$NON-NLS-1$
                + file
                + "', '" //$NON-NLS-1$
                + comment
                + "', reserved: " //$NON-NLS-1$
                + reserved
                + ", ptime: " //$NON-NLS-1$
                + ptime;
        log(info, msg, null);
        try
        {
            getElt(file).checkedOut = true;
        }
        catch (Throwable ex)
        {
            return new Status(false, msg + ", ex: " + ex); //$NON-NLS-1$
        }
        return new Status(true, msg);
    }
    
	public Status checkin(String file, String comment, boolean ptime)
	{
		String msg =
			"Checkin: '" + file + "', '" + comment + "', ptime: " + ptime; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		log(info, msg, null);
		try
		{
			getElt(file).checkedOut = false;
		}
		catch (Throwable ex)
		{
			return new Status(false, msg + ", ex: " + ex); //$NON-NLS-1$
		}
		return new Status(true, msg);
	}

	public Status uncheckout(String file, boolean keep)
	{
		String msg = "Uncheckout: '" + file + "', keep: " + keep; //$NON-NLS-1$ //$NON-NLS-2$
		log(info, msg, null);
		try
		{
			getElt(file).checkedOut = false;
		}
		catch (Throwable ex)
		{
			return new Status(false, msg + ", ex: " + ex); //$NON-NLS-1$
		}
		return new Status(true, msg);
	}

    
    /* (non-Javadoc)
     * @see net.sourceforge.clearcase.simple.IClearcase#add(java.lang.String, java.lang.String, boolean, boolean)
     */
    public Status add(String file, String comment, boolean isDirectory,
            boolean makeMaster) {
        String msg =
            "Add: '" //$NON-NLS-1$
                + file
                + "', '" //$NON-NLS-1$
                + comment
                + "', isdirectory: " //$NON-NLS-1$
                + isDirectory;
        log(info, msg, null);
        try
        {
            makeElt(file);
            if (isDirectory)
                new File(file).mkdir();
        }
        catch (Throwable ex)
        {
            return new Status(false, msg + ", ex: " + ex); //$NON-NLS-1$
        }
        return new Status(true, msg);
    }
    
	public Status delete(String file, String comment)
	{
		String msg = "Delete: '" + file + "', '" + comment + "'"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		log(info, msg, null);
		try
		{
			getElt(file);
			removeElt(file);
			new File(file).delete();
		}
		catch (Throwable ex)
		{
			return new Status(false, msg + ", ex: " + ex); //$NON-NLS-1$
		}
		return new Status(true, msg);
	}

	public Status move(String file, String newfile, String comment)
	{
		String msg =
			"Checkout: '" + file + "', '" + newfile + "', '" + comment + "'"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
		log(info, msg, null);

		try
		{
			getElt(file);
			new File(file).renameTo(new File(newfile));
		}
		catch (Throwable ex)
		{
			return new Status(false, msg + ", ex: " + ex); //$NON-NLS-1$
		}
		return new Status(true, msg);
	}

	public Status getViewName(String file)
	{
		String msg = "getViewName: '" + file + "'"; //$NON-NLS-1$ //$NON-NLS-2$
		log(info, msg, null);
		try
		{
			getElt(file);
		}
		catch (Throwable ex)
		{
			return new Status(false, msg + ", ex: " + ex); //$NON-NLS-1$
		}
		return new Status(true, "MyViewName"); //$NON-NLS-1$
	}
    
    public Status getViewRoot(String file)
    {
        String msg = "getViewRoot: '" + file + "'"; //$NON-NLS-1$ //$NON-NLS-2$
        log(info, msg, null);
        try
        {
            getElt(file);
        }
        catch (Throwable ex)
        {
            return new Status(false, msg + ", ex: " + ex); //$NON-NLS-1$
        }
        return new Status(true, "MyViewRoot"); //$NON-NLS-1$
    }


	public Status cleartool(String cmd)
	{
		String msg = "Cleartool: '" + cmd + "'"; //$NON-NLS-1$ //$NON-NLS-2$
		log(info, msg, null);
		return new Status(true, msg);
	}

	public boolean isCheckedOut(String file, boolean isSymbolicLink)
	{
		return getElt(file).checkedOut;
	}
    
    
    /* (non-Javadoc)
     * @see net.sourceforge.clearcase.simple.IClearcase#isCheckedOutInAnotherView(java.lang.String)
     */
    public boolean isCheckedOutInAnotherView(String file, boolean isSymbolicLink) {
        return false;
    }

	public boolean isElement(String file)
	{
		return isElt(file);
	}

	public boolean isDifferent(String file)
	{
		return isCheckedOut(file,isSymbolicLink(file));
	}

	public boolean isSnapShot(String file, boolean isSymbolicLink)
	{
		String msg = "isSnapShot: '" + file + "'"; //$NON-NLS-1$ //$NON-NLS-2$
		log(info, msg, null);
		return false;
	}

	public boolean isHijacked(String file, boolean isSymbolicLink)
	{
		String msg = "isHijacked: '" + file + "'"; //$NON-NLS-1$ //$NON-NLS-2$
		log(info, msg, null);
		return false;
	}

	public void destroy()
	{
		save(new File(SAVE_FILE_NAME));
	}

	public void save(File saveFile)
	{
		try
		{
			ObjectOutputStream os =
				new ObjectOutputStream(new FileOutputStream(saveFile));
			os.writeObject(eltMap);
			os.flush();
			os.close();
		}
		catch (Exception ex)
		{
			log(err, "Could not persist clearcase dummy element state", ex); //$NON-NLS-1$
		}
	}

	public void load(File loadFile)
	{
		try
		{
			if (loadFile.exists())
			{
				ObjectInputStream is =
					new ObjectInputStream(new FileInputStream(loadFile));
				eltMap = (Map) is.readObject();
				is.close();
			}
		}
		catch (Exception ex)
		{
			log(err, "Could not load saved clearcase dummy state", ex); //$NON-NLS-1$
		}

	}


    IClearcaseDebugger debugger;
    
    /* (non-Javadoc)
     * @see net.sourceforge.clearcase.simple.IClearcase#setDebugger(net.sourceforge.clearcase.simple.IClearcaseDebugger)
     */
    public void setDebugger(IClearcaseDebugger debugger)
    {
        this.debugger = debugger;
    }
    
    
    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#isSymbolicLink(java.lang.String)
     */
    public boolean isSymbolicLink(String file)
    {
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#getSymbolicLinkTarget(java.lang.String)
     */
    public Status getSymbolicLinkTarget(String file)
    {
        return new Status(false, ""); //$NON-NLS-1$
    }

    /* (non-Javadoc)
     * @see net.sourceforge.clearcase.simple.IClearcase#isSymbolicLinkTargetValid(java.lang.String)
     */
    public boolean isSymbolicLinkTargetValid(String file)
    {
        return true;
    }
}
