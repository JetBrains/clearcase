/*******************************************************************************
 * Copyright (c) 2002, 2004 eclipse-ccase.sourceforge.net.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Gunnar Wagenknecht - initial API and implementation
 *     IBM Corporation - concepts and ideas from Eclipse
 *******************************************************************************/

package net.sourceforge.clearcase.simple;

import org.apache.tools.ant.taskdefs.Execute;


/**
 * TODO Provide description for ClearDlg.
 *
 * @author Gunnar Wagenknecht (g.wagenknecht@planet-wagenknecht.de)
 */
public class ClearDlg extends Execute {

    private static final String CLEARDLG = "cleardlg"; //$NON-NLS-1$

    /**
     * Creates a new instance.
     * @param arguments
     */
    public ClearDlg(String[] arguments) {
        super();
        String[] commandLine = new String[arguments.length + 1];
        commandLine[0] = CLEARDLG;
        System.arraycopy(arguments, 0, commandLine, 1, arguments.length);
        setCommandline(commandLine);
    }

}
