package net.sourceforge.clearcase.simple;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import net.sourceforge.clearcase.simple.IClearcase.Status;

public class ClearcaseUtil
{

    public static String quote(String str)
    {
        StringBuffer result = new StringBuffer(str.length() + 10);
        result.append('"');
        // replace all double quotes with single quotes
        for (int i = 0; i < str.length(); ++i)
        {
            char c = str.charAt(i);
            switch (c)
            {
                case '"' :
                    result.append("''");
                    break;

                default :
                    result.append(c);
                    break;
            }
        }
        result.append('"');
        return result.toString();
    }

    private static void appendEscapedChar(StringBuffer buffer, char c)
    {
        String replacement = getReplacement(c);
        if (replacement != null)
        {
            buffer.append('&');
            buffer.append(replacement);
            buffer.append(';');
        }
        else
        {
            buffer.append(c);
        }
    }

    /**
     * Returns an escaped string that can be safely wrapped into 
     * double quotes (<code>&quot;</code>) and used on the command line.
     * 
     * <p>The replacement is similar to XML encoding:
     * <ul>
     * <li><code>&lt;</code> into <code>&amp;;</code></li>
     * <li><code>&gt;</code> into <code>&amp;gt;</code></li>
     * <li><code>&quot;</code> into <code>&amp;quot;</code></li>
     * <li><code>'</code> into <code>&amp;apos;</code></li>
     * <li><code>&amp;</code> into <code>&amp;amp;</code></li>
     * </ul>
     * </p>
     * @param s
     * @return
     */
    public static String getEscaped(String s)
    {
        StringBuffer result = new StringBuffer(s.length() + 10);
        for (int i = 0; i < s.length(); ++i)
            appendEscapedChar(result, s.charAt(i));
        return result.toString();
    }

    private static String getReplacement(char c)
    {
        // Encode special XML characters into the equivalent character references.
        // These five are defined by default for all XML documents.
        switch (c)
        {
            case '<' :
                return "lt"; //$NON-NLS-1$
            case '>' :
                return "gt"; //$NON-NLS-1$
            case '"' :
                return "quot"; //$NON-NLS-1$
            case '\'' :
                return "apos"; //$NON-NLS-1$
            case '&' :
                return "amp"; //$NON-NLS-1$
        }
        return null;
    }

    public static List findCheckins(
        IClearcase ccase,
        String path,
        String limitDate,
        String username)
        throws ClearcaseException
    {
        List resultList = new ArrayList();

        if (limitDate == null || limitDate.trim().length() == 0)
            limitDate = "today";

        String userbool = "";
        if (username != null && username.trim().length() > 0)
            userbool = "&&created_by(" + username + ")";

        IClearcase.Status result =
            ccase.cleartool(
                "find "
                    + quote(path)
                    + " -cview -version '{created_since("
                    + limitDate
                    + ")"
                    + userbool
                    + "}' -print");
        if (!result.status)
            throw new ClearcaseException(result.message);
        StringTokenizer st = new StringTokenizer(result.message, "\r\n");
        while (st.hasMoreTokens())
        {
            String item = st.nextToken();
            if (!item.endsWith("CHECKEDOUT"))
            {
                int idx = item.indexOf("@@");
                if (idx > -1)
                {
                    item = item.substring(0, idx);
                }
                resultList.add(item);
            }
        }
        return resultList;
    }

    public static List findCheckouts(IClearcase ccase, String path) throws ClearcaseException
    {
        // Faster to find all checkouts, and filter on path of interest, than it is to find checkouts for subtree.
        List resultList = new ArrayList();

        try
        {
            File prefixFile = new File(path);
            String prefix = prefixFile.getCanonicalPath();
            int slashIdx = prefix.indexOf(File.separator);
            String prefixNoDrive = prefix.substring(slashIdx);
            String drive = prefix.substring(0, slashIdx);

            IClearcase.Status viewNameStatus = ccase.getViewName(prefix);
            if (!viewNameStatus.status)
                throw new Exception(viewNameStatus.message);
            String viewName = viewNameStatus.message.trim();

            boolean isSnapShot = ccase.isSnapShot(prefix, ccase.isSymbolicLink(prefix));
            boolean projectHasViewPath = prefix.indexOf(viewName) != -1;

            IClearcase.Status result =
                ccase.cleartool("lsco -me -cview -short -all " + quote(prefix));
            if (!result.status)
                throw new Exception(result.message);

            StringTokenizer st = new StringTokenizer(result.message, "\r\n");
            while (st.hasMoreTokens())
            {
                String entry = st.nextToken();
                // If snapshot, or dynamic but path is in clearcase "views" directory,
                // then just add the filename verbatim, otherwise we need to clean it up by remapping
                // to the same drive/etc as path passed in.
                if (isSnapShot || projectHasViewPath)
                {
                    resultList.add(entry);
                }
                else
                {
                    int idx = entry.indexOf(viewName);
                    String cleanEntry;
                    if (idx == -1)
                    {
                        cleanEntry = entry;
                    }
                    else
                    {
                        idx += viewName.length();
                        cleanEntry = entry.substring(idx);
                    }
                    if (cleanEntry.startsWith(prefixNoDrive))
                        resultList.add(drive + cleanEntry);
                }

            }

            Collections.sort(resultList);
        }
        catch (Exception e)
        {
            throw new ClearcaseException(
                "Could not find checkouts for path: " + path + ", reason: " + e);
        }

        return resultList;
    }

    public static List findLabels(IClearcase ccase, String vobPath) throws ClearcaseException
    {
        List resultList = new ArrayList();
        IClearcase.Status result =
            ccase.cleartool("lstype -s -kind lbtype -invob " + quote(vobPath));
        if (!result.status)
            throw new ClearcaseException(result.message);
        StringTokenizer st = new StringTokenizer(result.message, "\r\n");
        while (st.hasMoreTokens())
        {
            resultList.add(st.nextToken());
        }
        return resultList;
    }

    public static List findVOBs(IClearcase ccase) throws ClearcaseException
    {
        List resultList = new ArrayList();
        IClearcase.Status result = ccase.cleartool("lsvob -s");
        if (!result.status)
            throw new ClearcaseException(result.message);
        StringTokenizer st = new StringTokenizer(result.message, "\r\n");
        while (st.hasMoreTokens())
        {
            resultList.add(st.nextToken());
        }
        return resultList;
    }

    public static void createLabel(IClearcase ccase, String label, String vobName)
        throws ClearcaseException
    {
        IClearcase.Status result = ccase.cleartool("mklbtype -nc " + quote(label));
        if (!result.status)
            throw new ClearcaseException(result.message);
    }

    public static void applyLabel(IClearcase ccase, String label, List elements, boolean recurse)
        throws ClearcaseException
    {
        for (Iterator iter = elements.iterator(); iter.hasNext();)
        {
            String each = iter.next().toString();
            // make the label - if it already exists, we'll fail silently
            ccase.cleartool("mklbtype -nc " + quote(label + "@" + each));
            IClearcase.Status result =
                ccase.cleartool(
                    "mklabel -replace "
                        + (recurse ? "-recurse " : "")
                        + quote(label)
                        + " "
                        + quote(each));
            if (!result.status)
                throw new ClearcaseException(result.message);
        }
    }

    public static String applyCommand(
        IClearcase ccase,
        String command,
        List elements,
        boolean applyIndividually)
        throws ClearcaseException
    {
        StringBuffer resultBuffer = new StringBuffer();
        StringBuffer cmdBuffer = new StringBuffer();
        cmdBuffer.append(command);

        for (Iterator iter = elements.iterator(); iter.hasNext();)
        {
            String each = iter.next().toString();
            if (applyIndividually)
            {
                IClearcase.Status result = ccase.cleartool(command + " " + quote(each));
                if (!result.status)
                    throw new ClearcaseException(result.message);
                resultBuffer.append(result.message);
                resultBuffer.append(System.getProperty("line.separator"));
            }
            else
            {
                cmdBuffer.append(" ");
                cmdBuffer.append(each);
            }
        }
        if (!applyIndividually)
        {
            IClearcase.Status result = ccase.cleartool(cmdBuffer.toString());
            if (!result.status)
                throw new ClearcaseException(result.message);
            resultBuffer.append(result.message);
        }
        return resultBuffer.toString();
    }

    public static List cleartool(IClearcase ccase, String command) throws ClearcaseException
    {
        List resultList = new ArrayList();
        IClearcase.Status result = ccase.cleartool(command);
        if (!result.status)
            throw new ClearcaseException(result.message);
        StringTokenizer st = new StringTokenizer(result.message, "\r\n");
        while (st.hasMoreTokens())
        {
            resultList.add(st.nextToken());
        }
        return resultList;
    }

    public static void add(IClearcase ccase, File file, String comment, boolean makeMaster) throws ClearcaseException
    {
        // Sanity check - can't add something that already is under VC
        if (ccase.isElement(file.toString()))
        {
            throw new ClearcaseException(
                "Cannot add an element already under version control: " + file.toString());
        }
        // Walk up parent heirarchy, find first ccase
        // element that is a parent, and walk back down, adding each to ccase
        File parent = file.getParentFile();

        if (parent == null)
        {
            throw new ClearcaseException("Only files with some parent that is a clearcase element can be added to clearcase.");
        }

        // If parent is in clearcase, check it out, otherwise try and add it with
        // a recursive call
        if (ccase.isElement(parent.toString()))
        {
            if (!ccase.isCheckedOut(parent.toString(),ccase.isSymbolicLink(parent.toString())))
            {
                Status result = ccase.checkout(parent.toString(), comment, false, true);
                if (!result.status)
                {
                    throw new ClearcaseException(
                        "Could not checkout: " + parent + " due to: " + result.message);
                }
            }
        }
        else
        {
            add(ccase, parent, comment, makeMaster);
        }

        if (file.isDirectory())
        {
            String path = file.toString();
            File origfolder = new File(path);
            File mkelemfolder = new File(path + ".mkelem");
            origfolder.renameTo(mkelemfolder);
            Status status = ccase.add(path, comment, true, makeMaster);
            if (status.status)
            {
                File[] members = mkelemfolder.listFiles();
                for (int i = 0; i < members.length; i++)
                {
                    File member = members[i];
                    File newMember = new File(origfolder.getPath(), member.getName());
                    member.renameTo(newMember);
                }
                mkelemfolder.delete();
            }
            else
            {
                throw new ClearcaseException("Add failed: " + status.message);
            }
        }
        else
        {
            Status status = ccase.add(file.toString(), comment, false, makeMaster);
            if (!status.status)
            {
                throw new ClearcaseException("Add failed: " + status.message);
            }
        }
    }

}
