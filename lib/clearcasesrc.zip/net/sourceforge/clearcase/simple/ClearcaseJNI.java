package net.sourceforge.clearcase.simple;

import java.io.File;

import net.sourceforge.clearcase.comapi.Application;
import net.sourceforge.clearcase.comapi.CCKeepState;
import net.sourceforge.clearcase.comapi.CCReservedState;
import net.sourceforge.clearcase.comapi.CCVersionToCheckOut;
import net.sourceforge.clearcase.comapi.ClearTool;
import net.sourceforge.clearcase.comapi.ICCCheckedOutFile;
import net.sourceforge.clearcase.comapi.ICCElement;
import net.sourceforge.clearcase.comapi.ICCVersion;
import net.sourceforge.clearcase.comapi.ICCView;
import net.sourceforge.clearcase.comapi.IClearCase;
import net.sourceforge.clearcase.comapi.IClearTool;

import com.jacob.com.JacobObject;
import com.jacob.com.Variant;

public class ClearcaseJNI implements IClearcase {
	//single instance of Clearcase application, all calls to it are done in a synchronized way
    private static final IClearCase ccase = new Application();

    // synchronize all access in the hopes it fixes JVM crashes
    public synchronized void destroy() {
        // nothing
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#add(java.lang.String,
     *      java.lang.String, boolean, boolean)
     */
    public synchronized Status add(String file, String comment,
            boolean isDirectory, boolean makeMaster) {
        Status result;
        ICCCheckedOutFile cofile = null;
        Variant dir = null;
        try {
            if (isDirectory) {
                dir = new Variant("directory");
                cofile = ccase.createElement(file, comment, makeMaster, dir);
            } else
                cofile = ccase.createElement(file, comment, makeMaster);

            if (null != cofile)
                result = new Status(true, "Add Successful");
            else
                result = new Status(false, "Add Error");
        } catch (Exception ex) {
            result = new Status(false, ex.getMessage());
        } finally {
            release(cofile);
            release(dir);
        }
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#checkin(String, String,
     *      boolean)
     */
    public synchronized Status checkin(String file, String comment,
            boolean ptime) {
        Status result;
        ICCCheckedOutFile cofile = null;

        try {
            if (isSymbolicLink(file)) {
                String oldFile = file;
                file = getResolvedLinkTarget(file);
                if (null == file)
                    throw new RuntimeException("Invalid link target: "
                            + oldFile);
            }

            if (ptime) {
                result = cleartool("checkin -identical -ptime "
                        + getArgumentWithComment(comment, ClearcaseUtil
                                .quote(file)));
                if (result.status)
                    result.message = "Checkin Successful";
            } else {
                if (null != getVersion(file)) {
                    cofile = ccase.getCheckedOutFile(file);
                    cofile.checkIn(comment, true, "", CCKeepState.ccRemove);
                    result = new Status(true, "Checkin Successful");
                } else {
                    result = new Status(false, "No Element");
                }
            }
        } catch (Exception ex) {
            result = new Status(false, ex.getMessage());
        } finally {
            release(cofile);
        }
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#checkout(java.lang.String,
     *      java.lang.String, boolean, boolean, boolean, boolean)
     */
    public synchronized Status checkout(String file, String comment,
            boolean reserved, boolean ptime) {
        Status result;
        ICCCheckedOutFile cofile = null;
        ICCVersion version = null;
        try {
            if (isSymbolicLink(file)) {
                String oldFile = file;
                file = getResolvedLinkTarget(file);
                if (null == file)
                    throw new RuntimeException("Invalid link target: "
                            + oldFile);
            }

            version = getVersion(file);

            long lastModified = new File(file).lastModified();
            cofile = version.checkOut(reserved ? CCReservedState.ccReserved
                    : CCReservedState.ccUnreserved, comment, false,
                    CCVersionToCheckOut.ccVersion_Default, false, ptime);
            if (null != cofile) {
                if(ptime && lastModified > 0L) {
                    File fileObj = new File(file);
                    if(lastModified != fileObj.lastModified()) {
                        fileObj.setLastModified(lastModified);
                        System.out.println("!!! manual setting modification time !!!");
                    }
                }
                result = new Status(true, "Checkout Successful");
            }
            else
                result = new Status(false, "Checkout Error");
        } catch (Exception ex) {
            result = new Status(false, ex.getMessage());
        } finally {
            
            release(cofile);
            release(version);
        }
        return result;
    }

    /*
     * @see net.sourceforge.eclipseccase.IClearcase#cleartool(String)
     */
    public synchronized Status cleartool(String cmd) {
        if (null != debugger)
            debugger.debugClearcase("ClearCaseJNI", "[execute]: " + cmd);

        Status result;
        IClearTool cleartool = null;
        try {
            cleartool = new ClearTool();
            String output = cleartool.cmdExec(cmd);
            if (output == null)
                output = "";
            result = new Status(true, output);
        } catch (Exception ex) {
            if (null != debugger)
                debugger.debugClearcase("ClearCaseJNI", "[error]: "
                        + ex.getMessage());

            result = new Status(false, ex.getMessage());
        } finally {
            release(cleartool);
        }
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#delete(String, String)
     */
    public synchronized Status delete(String file, String comment) {
        Status result;
        ICCElement element = null;
        try {
            if (isSymbolicLink(file)) {
                throw new RuntimeException("Cannot delete link: " + file);
            }
            element = ccase.getElement(file);
            element.removeName(comment, true);
            result = new Status(true, "Delete Successful");
        } catch (Exception ex) {
            result = new Status(false, ex.getMessage());
        } finally {
            release(element);
        }
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#getViewName(String)
     */
    public synchronized Status getViewName(String file) {
        return getInfo(file).getViewName();
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#getViewRoot(java.lang.String)
     */
    public Status getViewRoot(String file) {
        Status result;
        try {
            File dir = new File(file);
            if (!dir.isDirectory())
                dir = dir.getParentFile();
            synchronized (this) {
                result = cleartool("cd " + ClearcaseUtil.quote(dir.getPath()));
                if (result.status)
                    result = cleartool("pwv -root");
            }
        } catch (Exception ex) {
            result = new Status(false, ex.getMessage());
        }
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isCheckedOut(String,boolean)
     */
    public synchronized boolean isCheckedOut(String file, boolean isSymbolicLink) {
        boolean result;
        ICCVersion version = null;
        try {
            if (isSymbolicLink) {
                file = getResolvedLinkTarget(file);
                if (null == file)
                    return false;
            }
            version = getVersion(file);
            result = null != version && version.getIsCheckedOut();
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getClass().getName() + ": "
                    + ex.getMessage(), ex);
        } finally {
            release(version);
        }
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#isCheckedOutInAnotherView(String,
     *      boolean)
     */
    public synchronized boolean isCheckedOutInAnotherView(String file,
            boolean isSymbolicLink) {
        try {
            if (isSymbolicLink) {
                file = getResolvedLinkTarget(file);
                if (null == file)
                    return false;
            }

            Status status = getViewName(file);
            if (status.status && status.message.trim().length() > 0) {
                String currentView = status.message.trim();
                status = cleartool("lsco -d -fmt " + ClearcaseUtil.quote("%Tf")
                        + " " + ClearcaseUtil.quote(file));
                if (status.status && status.message.trim().length() > 0
                        && !currentView.equals(status.message.trim()))
                    return true;
            }
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getClass().getName() + ": "
                    + ex.getMessage(), ex);
        }
        // file is not checked out
        return false;
    }

    /**
     * @param file
     * @return
     */
    private synchronized String getResolvedLinkTarget(String file) {
        return getInfo(file).getResolvedLinkTarget();
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#isSymbolicLinkTargetValid(java.lang.String)
     */
    public boolean isSymbolicLinkTargetValid(String file) {
        /*
         * A link target is valid if it exists in the file system. That means
         * that Clearcase could resolve it.
         */
        return new File(file).exists() || null != getResolvedLinkTarget(file);
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isDifferent(String)
     */
    public synchronized boolean isDifferent(String file) {
        boolean result = false;
        ICCVersion version = null;
        try {
            if (isSymbolicLink(file)) {
                file = getResolvedLinkTarget(file);
                if (null == file)
                    return false;
            }

            version = getVersion(file);
            result =  null != version && version.getIsCheckedOut() && version.getIsDifferent();
        } catch (Exception ex) {
            // could not determine version, ignore;
        } finally {
            release(version);
        }
        return result;
    }

    /**
     * @param file
     * @return
     */
    private ICCVersion getVersion(String file) {
        return getInfo(file).getVersion();
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isElement(String)
     */
    public synchronized boolean isElement(String file) {

        ICCVersion version = getVersion(file);
        if (null != version) {
            release(version);
            return true;
        }
        // we may still have a link
        return isSymbolicLink(file);
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#isSymbolicLink(java.lang.String)
     */
    public synchronized boolean isSymbolicLink(String file) {
        return getInfo(file).isSymbolicLink();
    }

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#getSymbolicLinkTarget(java.lang.String)
     */
    public Status getSymbolicLinkTarget(String file) {
        return getInfo(file).getSymbolicLinkTarget();
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isHijacked(String,boolean)
     */
    public synchronized boolean isHijacked(String file, boolean isSymbolicLink) {
        boolean result = false;
        ICCVersion version = null;
        try {
            if (isSymbolicLink) {
                file = getResolvedLinkTarget(file);
                if (null == file)
                    return false;
            }
            version = getVersion(file);
            result = version.getIsHijacked();
        } catch (Exception ex) {
            // nothing
        } finally {
            release(version);
        }
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#isSnapShot(String,boolean)
     */
    public synchronized boolean isSnapShot(String file, boolean isSymbolicLink) {
        boolean result = false;
        ICCView view = null;
        try {
            if (isSymbolicLink) {
                file = getResolvedLinkTarget(file);
                if (null == file)
                    return false;
            }
            view = ccase.getView(file);
            result = view.getIsSnapShot();
        } catch (Exception ex) {
            // nothing
        } finally {
            release(view);
        }
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#move(String, String, String)
     */
    public synchronized Status move(String file, String newfile, String comment) {
        Status result;
        ICCElement element = null;
        try {
            if (isSymbolicLink(file)) {
                throw new RuntimeException("Cannot move link: " + file);
            }
            element = ccase.getElement(file);
            element.rename(newfile, comment);
            result = new Status(true, "Move Successful");
        } catch (Exception ex) {
            result = new Status(false, ex.getMessage());
        } finally {
            release(element);
        }
        return result;
    }

    /**
     * @see net.sourceforge.eclipseccase.IClearcase#uncheckout(String, boolean)
     */
    public synchronized Status uncheckout(String file, boolean keep) {
        Status result;
        ICCCheckedOutFile cofile = null;
        try {
            if (isSymbolicLink(file)) {
                String oldFile = file;
                file = getResolvedLinkTarget(file);
                if (null == file)
                    throw new RuntimeException("Invalid link target: "
                            + oldFile);
            }
            cofile = ccase.getCheckedOutFile(file);
            cofile.unCheckOut(keep ? CCKeepState.ccKeep : CCKeepState.ccRemove);
            result = new Status(true, "Uncheckout Successful");
        } catch (Exception ex) {
            result = new Status(false, ex.getMessage());
        } finally {
            release(cofile);
        }
        return result;
    }

    /**
     * Returns the argument with comment for the cleartool command.
     * <p>
     * Due to cleartool limits, the comment will be forced to be a single line.
     * 
     * @param comment
     * @param argument
     * @return the argument with comment
     */
    private final String getArgumentWithComment(String comment, String argument) {
        if (comment.indexOf('\n') != -1 || comment.indexOf('\r') != -1) {
            StringBuffer buffer = new StringBuffer(comment.length());
            for (int i = 0; i < comment.length(); i++) {
                char c = comment.charAt(i);
                switch (c) {
                case '\r':
                    //buffer.append("\\r");
                    // drop
                    break;

                case '\n':
                    //buffer.append("\\n");
                    buffer.append(" ");
                    break;

                default:
                    buffer.append(c);
                    break;
                }
            }
            comment = buffer.toString();
        }
        return "-c " + ClearcaseUtil.quote(comment) + " " + argument;
    }

    IClearcaseDebugger debugger;

    /*
     * (non-Javadoc)
     * 
     * @see net.sourceforge.clearcase.simple.IClearcase#setDebugger(net.sourceforge.clearcase.simple.IClearcaseDebugger)
     */
    public void setDebugger(IClearcaseDebugger debugger) {
        this.debugger = debugger;
    }

    private void release(JacobObject jacobObject) {
        // ATTENTION, do not release if it's a cached version object
        if (jacobObject != null && jacobObject != cache.version) {
                jacobObject.release();
        }
    }

    /* (non-Javadoc)
     * @see java.lang.Object#finalize()
     */
    protected void finalize() throws Throwable {
        super.finalize();
        release(ccase);
    }

    /**
     * the short living CC info
     */
    Info cache = new Info("");

    Info getInfo(String file) {
        return cache.getInfo(file);
    }

    /**
     * The version of a file is used in several public getters. Often these
     * getters are called in a series of consecutive calls during which the
     * version of a file does not change.
     * <ul>
     * <li>{@linkplain #isHijacked(String) isHijacked}</li>
     * <li>{@linkplain #isCheckedOut(String) isCheckedOut}</li>
     * <li>{@linkplain #isElement(String) isElement}</li>
     * <li>{@linkplain #isDifferent(String) isDifferent}</li>
     * </ul>
     * <p>
     * This method caches this version for a short time to prevent to many calls
     * to the JNI layer. The lifetime of such a cached version can be
     * {@link #setCacheTimeout(long) set}
     * 
     * @param file
     *            The file for which to get the version.
     * @return ICCVersion for the given file.
     */
    private class Info {
        Info(String file) {
            reset(file);
        }

        Info getInfo(String file) {
            reset(file);
            return this;
        }

        private void reset(String file) {
            m_file = file;
            m_moment = System.currentTimeMillis();

            resolvedLinkTarget = null;
            gotResolvedLinkTarget = false;

            symbolicLinkTarget = null;
            gotSymbolicLinkTarget = false;

            if(null != version) version.release();
            version = null;
            gotVersion = false;

            viewName = null;
            gotViewName = false;

            isSymbolicLink = null;
        }

//        private boolean needsRefresh() {
//            return (lifeTime <= 0 && System.currentTimeMillis() > (m_moment + lifeTime*1000));
//        }

        /** The file for which the latest cached version was retrieved */
        String m_file;

        /** The moment when the last version was cached (in ms) */
        long m_moment;

        String resolvedLinkTarget;

        boolean gotResolvedLinkTarget;

        Status symbolicLinkTarget;

        boolean gotSymbolicLinkTarget;

        ICCVersion version;

        boolean gotVersion;

        Status viewName;

        boolean gotViewName;

        Boolean isSymbolicLink;

        boolean isSymbolicLink() {
            if (isSymbolicLink == null) {
                isSymbolicLink = Boolean.FALSE;
                try {
                    Status status = cleartool("describe -fmt \"%m\" "
                            + ClearcaseUtil.quote(m_file));
                    if (status.status
                            && status.message.indexOf("symbolic link") >= 0)
                        isSymbolicLink = Boolean.TRUE;
                } catch (Exception ex) {
                    // ignore
                }
            }
            return isSymbolicLink.booleanValue();
        }

        ICCVersion getVersion() {
            Variant variant = null;
			if (!gotVersion || version == null) {
                version = null;
                
                try {
                	variant = new Variant(m_file);
                    version = ccase.getVersion(variant);
                } catch (Exception e) {
                    //nothing
                }
                finally{
                	release(variant);
                }
            }
            gotVersion = true;
            // ensure we never return null
            return version;
        }

        Status getSymbolicLinkTarget() {
            if (!gotSymbolicLinkTarget) {
                symbolicLinkTarget = new Status(false, "");

                try {
                    if (isSymbolicLink()) {
                        Status status = cleartool("describe -fmt \"%[slink_text]p\" "
                                + ClearcaseUtil.quote(m_file));
                        if (status.status) symbolicLinkTarget = status;
                    }
                } catch (Exception ex) {
                    // ignore
                }
            }
            gotSymbolicLinkTarget = true;
            return symbolicLinkTarget;
        }

        Status getViewName() {        
        	ICCView view = null;
            if (!gotViewName) {
                viewName = new Status(false, "");
                try {
                    view = ccase.getView(m_file);
                    viewName = new Status(true, view.getTagName());
                } catch (Exception ex) {
                    viewName = new Status(false, ex.getMessage());
                }
                finally
                {
                	release(view);
                }
            }
            gotViewName = true;
            return viewName;
        }

        String getResolvedLinkTarget() {
            if (!gotResolvedLinkTarget) {
                resolvedLinkTarget = null;
                Status status = getSymbolicLinkTarget();
                if (status.status) {
                    File target = new File(status.message);
                    if (target.isAbsolute())
                        return target.exists() ? target.getAbsolutePath()
                                : null;

                    // target is relative to source
                    File parent = new File(m_file).getParentFile();
                    if (null == parent) return null;
                    target = new File(parent, status.message);
                    resolvedLinkTarget = target.exists() ? target
                            .getAbsolutePath() : null;
                }
            }
            gotResolvedLinkTarget = true;
            return resolvedLinkTarget;
        }
    }
}