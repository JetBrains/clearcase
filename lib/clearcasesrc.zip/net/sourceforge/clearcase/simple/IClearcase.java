/*******************************************************************************
 * Copyright (c) 2002, 2004 eclipse-ccase.sourceforge.net.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Matthew Conway - initial API and implementation
 *     IBM Corporation - concepts and ideas from Eclipse
 *     Gunnar Wagenknecht - new features, enhancements and bug fixes
 *******************************************************************************/
package net.sourceforge.clearcase.simple;

/**
 * The interface to ClearCase.
 * <p>
 * This interface defines the API for operating with ClearCase.
 * </p>
 * 
 * <p>
 * Clients must not implement this interface.
 * </p>
 * 
 * <p>
 * Note that his API is suspect to change until a final 1.0 version is
 * officially announced.
 * </p>
 */
public interface IClearcase {
	//RDM: caching of similar clearcase calls is completely disabled again.
	//see bug 1069529 for more info
//    /**
//     * The lifetime of the cache file version in seconds.
//     */
//    public static long lifeTime = 0;

    /**
     * The status
     */
    public static class Status {

        public boolean status;

        public String message;

        public Status(boolean status, String message) {
            this.status = status;
            this.message = message;
        }
    }

    /** Destroys this instance */
    public void destroy();

    /**
     * Does a clearcase checkout of the given file.
     * <p>
     * Comment can be empty string. If reserved is <code>true</code>, does a
     * reserved checkout. <code>ptime</code> preserves file timestamp.
     * </p>
     * 
     * @param file
     *            the file
     * @param comment
     *            the comment
     * @param reserved
     * @param ptime
     */
    public Status checkout(String file, String comment, boolean reserved,
            boolean ptime);

    /**
     * Does a clearcase checkin of the given file. Comment can be empty string.
     * ptime preserves file timestamp
     */
    public Status checkin(String file, String comment, boolean ptime);

    /**
     * Does a clearcase uncheckout of the given file. If keep is true, the file
     * is copied to a ".keep" file
     */
    public Status uncheckout(String file, boolean keep);

    /**
     * Adds the given file to clearcase source control.
     * <p>
     * This requires the parent directory to be under version control and
     * checked out. The isdirectory flag causes creation of a directory element
     * when true. Comment can be empty string.
     * </p>
     * 
     * @param file
     *            (may not be <code>null</code>)
     * @param comment
     *            the comment (may not be <code>null</code>)
     * @param isDirectory
     *            indicates if the element is a directory
     * @param makeMaster
     *            indicates if the element should be the master for replicas
     */
    public Status add(String file, String comment, boolean isDirectory,
            boolean makeMaster);

    /**
     * Removes the given file from clearcase source control (rmname NOT rmelem).
     * This requires the parent directory to be under version control and
     * checked out. Comment can be empty string.
     */
    public Status delete(String file, String comment);

    /**
     * Moves file to newfile. The parent directories of both file and newfile
     * must be checked out. Comment can be empty string.
     */
    public Status move(String file, String newfile, String comment);

    /** Gets the view tag name for the view associated with file. */
    public Status getViewName(String file);

    /** Gets the view root path for the view associated with file. */
    public Status getViewRoot(String file);

    /**
     * Executes the command "cmd" just like a command line "cleartool cmd".
     */
    public Status cleartool(String cmd);

    /**
     * Returns true if the file is under version control and checked out
     */
    public boolean isCheckedOut(String file, boolean isSymbolicLink);

    /**
     * Returns true if the file is under clearcase version control
     */
    public boolean isElement(String file);

    /**
     * Returns true if the file is a link
     */
    public boolean isSymbolicLink(String file);

    /**
     * Returns true if the link has a valid target
     */
    public boolean isSymbolicLinkTargetValid(String file);

    /**
     * Returns the target for a link.
     */
    public Status getSymbolicLinkTarget(String file);

    /**
     * Returns true if the file is checked out and different from its
     * predecessor
     */
    public boolean isDifferent(String file);

    /**
     * Indicates if the file is not checked out in this view but in another
     * view.
     * 
     * @param file
     * @return <code>true</code> if the file is checked out in another view
     */
    public boolean isCheckedOutInAnotherView(String file, boolean isSymbolicLink);

    /**
     * Returns true if the file is under version control and part of a snapshot
     * view
     */
    public boolean isSnapShot(String file, boolean isSymbolicLink);

    /**
     * Returns true if the file is under version control and hijacked from a
     * snapshot view
     */
    public boolean isHijacked(String file, boolean isSymbolicLink);

    /**
     * Sets the debugger.
     * 
     * @param debugger
     *            the debugger to set
     */
    void setDebugger(IClearcaseDebugger debugger);
}