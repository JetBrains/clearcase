/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCLabelTypes extends ICCLabelTypes {

	public static final String componentName = "ClearCase.CCLabelTypes"; //$NON-NLS-1$

	public CCLabelTypes() {
		super(componentName);
	}

	public CCLabelTypes(Dispatch d) {
		super(d);
	}
}
