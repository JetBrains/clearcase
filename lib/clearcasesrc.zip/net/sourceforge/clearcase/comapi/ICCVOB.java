/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCVOB extends Dispatch {

	public static final String componentName = "ClearCase.ICCVOB"; //$NON-NLS-1$

	public ICCVOB() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCVOB(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCVOB(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch()); //$NON-NLS-1$
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString(); //$NON-NLS-1$
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam); //$NON-NLS-1$
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch()); //$NON-NLS-1$
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString(); //$NON-NLS-1$
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString(); //$NON-NLS-1$
	}

	public String getTagName() {
		return Dispatch.get(this, "TagName").toString(); //$NON-NLS-1$
	}

	public ICCActivity getActivity(String lastParam) {
		return new ICCActivity(Dispatch.call(this, "Activity", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public Variant getAdditionalGroupsStringArray() {
		return Dispatch.get(this, "AdditionalGroupsStringArray"); //$NON-NLS-1$
	}

	public ICCAttributeType getAttributeType(String name, boolean lastParam) {
		return new ICCAttributeType(Dispatch.call(this, "AttributeType", name, new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeType getAttributeType(String name) {
		return new ICCAttributeType(Dispatch.call(this, "AttributeType", name).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeTypes getAttributeTypes(boolean local, boolean lastParam) {
		return new ICCAttributeTypes(Dispatch.call(this, "AttributeTypes", new Variant(local), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeTypes getAttributeTypes(boolean local) {
		return new ICCAttributeTypes(Dispatch.call(this, "AttributeTypes", new Variant(local)).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeTypes getAttributeTypes() {
		return new ICCAttributeTypes(Dispatch.get(this, "AttributeTypes").toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchType getBranchType(String name, boolean lastParam) {
		return new ICCBranchType(Dispatch.call(this, "BranchType", name, new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchType getBranchType(String name) {
		return new ICCBranchType(Dispatch.call(this, "BranchType", name).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchTypes getBranchTypes(boolean local, boolean lastParam) {
		return new ICCBranchTypes(Dispatch.call(this, "BranchTypes", new Variant(local), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchTypes getBranchTypes(boolean local) {
		return new ICCBranchTypes(Dispatch.call(this, "BranchTypes", new Variant(local)).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchTypes getBranchTypes() {
		return new ICCBranchTypes(Dispatch.get(this, "BranchTypes").toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment, boolean shared, int constraint, boolean global, boolean lastParam) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment, new Variant(shared), new Variant(constraint), new Variant(global), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment, boolean shared, int constraint, boolean global) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment, new Variant(shared), new Variant(constraint), new Variant(global)).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment, boolean shared, int constraint) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment, new Variant(shared), new Variant(constraint)).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment, boolean shared) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment, new Variant(shared)).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeType createAttributeType(String name, int valueType, String comment) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType), comment).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeType createAttributeType(String name, int valueType) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name, new Variant(valueType)).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeType createAttributeType(String name) {
		return new ICCAttributeType(Dispatch.call(this, "CreateAttributeType", name).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchType createBranchType(String name, String comment, int constraint, boolean global, boolean lastParam) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name, comment, new Variant(constraint), new Variant(global), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchType createBranchType(String name, String comment, int constraint, boolean global) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name, comment, new Variant(constraint), new Variant(global)).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchType createBranchType(String name, String comment, int constraint) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name, comment, new Variant(constraint)).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchType createBranchType(String name, String comment) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name, comment).toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchType createBranchType(String name) {
		return new ICCBranchType(Dispatch.call(this, "CreateBranchType", name).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkType createHyperlinkType(String name, String comment, boolean shared, boolean global, boolean lastParam) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name, comment, new Variant(shared), new Variant(global), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkType createHyperlinkType(String name, String comment, boolean shared, boolean global) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name, comment, new Variant(shared), new Variant(global)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkType createHyperlinkType(String name, String comment, boolean shared) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name, comment, new Variant(shared)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkType createHyperlinkType(String name, String comment) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name, comment).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkType createHyperlinkType(String name) {
		return new ICCHyperlinkType(Dispatch.call(this, "CreateHyperlinkType", name).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelType createLabelType(String name, String comment, boolean shared, int constraint, boolean global, boolean lastParam) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment, new Variant(shared), new Variant(constraint), new Variant(global), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelType createLabelType(String name, String comment, boolean shared, int constraint, boolean global) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment, new Variant(shared), new Variant(constraint), new Variant(global)).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelType createLabelType(String name, String comment, boolean shared, int constraint) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment, new Variant(shared), new Variant(constraint)).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelType createLabelType(String name, String comment, boolean shared) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment, new Variant(shared)).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelType createLabelType(String name, String comment) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name, comment).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelType createLabelType(String name) {
		return new ICCLabelType(Dispatch.call(this, "CreateLabelType", name).toDispatch()); //$NON-NLS-1$
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam); //$NON-NLS-1$
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete)); //$NON-NLS-1$
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment); //$NON-NLS-1$
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock"); //$NON-NLS-1$
	}

	public ICCTriggerTypeBuilder createTriggerTypeBuilder() {
		return new ICCTriggerTypeBuilder(Dispatch.call(this, "CreateTriggerTypeBuilder").toDispatch()); //$NON-NLS-1$
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString(); //$NON-NLS-1$
	}

	public boolean getHasMSDOSTextMode() {
		return Dispatch.get(this, "HasMSDOSTextMode").toBoolean(); //$NON-NLS-1$
	}

	public String getHost() {
		return Dispatch.get(this, "Host").toString(); //$NON-NLS-1$
	}

	public ICCHyperlink getHyperlink(String lastParam) {
		return new ICCHyperlink(Dispatch.call(this, "Hyperlink", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkType getHyperlinkType(String name, boolean lastParam) {
		return new ICCHyperlinkType(Dispatch.call(this, "HyperlinkType", name, new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkType getHyperlinkType(String name) {
		return new ICCHyperlinkType(Dispatch.call(this, "HyperlinkType", name).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkTypes getHyperlinkTypes(boolean local, boolean lastParam) {
		return new ICCHyperlinkTypes(Dispatch.call(this, "HyperlinkTypes", new Variant(local), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkTypes getHyperlinkTypes(boolean local) {
		return new ICCHyperlinkTypes(Dispatch.call(this, "HyperlinkTypes", new Variant(local)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkTypes getHyperlinkTypes() {
		return new ICCHyperlinkTypes(Dispatch.get(this, "HyperlinkTypes").toDispatch()); //$NON-NLS-1$
	}

	public boolean getIsMounted() {
		return Dispatch.get(this, "IsMounted").toBoolean(); //$NON-NLS-1$
	}

	public void setIsMounted(boolean lastParam) {
		Dispatch.put(this, "IsMounted", new Variant(lastParam)); //$NON-NLS-1$
	}

	public void setIsPersistent(boolean lastParam) {
		Dispatch.put(this, "IsPersistent", new Variant(lastParam)); //$NON-NLS-1$
	}

	public boolean getIsReplicated() {
		return Dispatch.get(this, "IsReplicated").toBoolean(); //$NON-NLS-1$
	}

	public ICCLabelType getLabelType(String name, boolean lastParam) {
		return new ICCLabelType(Dispatch.call(this, "LabelType", name, new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelType getLabelType(String name) {
		return new ICCLabelType(Dispatch.call(this, "LabelType", name).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelTypes getLabelTypes(boolean local, boolean lastParam) {
		return new ICCLabelTypes(Dispatch.call(this, "LabelTypes", new Variant(local), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelTypes getLabelTypes(boolean local) {
		return new ICCLabelTypes(Dispatch.call(this, "LabelTypes", new Variant(local)).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelTypes getLabelTypes() {
		return new ICCLabelTypes(Dispatch.get(this, "LabelTypes").toDispatch()); //$NON-NLS-1$
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch()); //$NON-NLS-1$
	}

	public ICCLocks getLocks(boolean lastParam) {
		return new ICCLocks(Dispatch.call(this, "Locks", new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCLocks getLocks() {
		return new ICCLocks(Dispatch.get(this, "Locks").toDispatch()); //$NON-NLS-1$
	}

	public String getMaster() {
		return Dispatch.get(this, "Master").toString(); //$NON-NLS-1$
	}

	public int getNumberOfAdditionalGroups() {
		return Dispatch.get(this, "NumberOfAdditionalGroups").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfReplicas() {
		return Dispatch.get(this, "NumberOfReplicas").toInt(); //$NON-NLS-1$
	}

	public String getOwner() {
		return Dispatch.get(this, "Owner").toString(); //$NON-NLS-1$
	}

	public void protect(String newOwner, String newGroup, Variant groupsToAddStringArray, Variant lastParam) {
		Dispatch.call(this, "Protect", newOwner, newGroup, groupsToAddStringArray, lastParam); //$NON-NLS-1$
	}

	public void protect(String newOwner, String newGroup, Variant groupsToAddStringArray) {
		Dispatch.call(this, "Protect", newOwner, newGroup, groupsToAddStringArray); //$NON-NLS-1$
	}

	public void protect(String newOwner, String newGroup) {
		Dispatch.call(this, "Protect", newOwner, newGroup); //$NON-NLS-1$
	}

	public void protect(String newOwner) {
		Dispatch.call(this, "Protect", newOwner); //$NON-NLS-1$
	}

	public void protect() {
		Dispatch.call(this, "Protect"); //$NON-NLS-1$
	}

	public Variant getReplicasStringArray() {
		return Dispatch.get(this, "ReplicasStringArray"); //$NON-NLS-1$
	}

	public void setMaster(String replica, String lastParam) {
		Dispatch.call(this, "SetMaster", replica, lastParam); //$NON-NLS-1$
	}

	public void setMaster(String replica) {
		Dispatch.call(this, "SetMaster", replica); //$NON-NLS-1$
	}

	public String getThisReplica() {
		return Dispatch.get(this, "ThisReplica").toString(); //$NON-NLS-1$
	}

	public ICCTriggerType getTriggerType(String lastParam) {
		return new ICCTriggerType(Dispatch.call(this, "TriggerType", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCTriggerTypes getTriggerTypes(boolean lastParam) {
		return new ICCTriggerTypes(Dispatch.call(this, "TriggerTypes", new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCTriggerTypes getTriggerTypes() {
		return new ICCTriggerTypes(Dispatch.get(this, "TriggerTypes").toDispatch()); //$NON-NLS-1$
	}

}
