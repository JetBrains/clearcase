/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCFolder extends ICCFolder {

	public static final String componentName = "ClearCase.CCFolder"; //$NON-NLS-1$

	public CCFolder() {
		super(componentName);
	}

	public CCFolder(Dispatch d) {
		super(d);
	}
}
