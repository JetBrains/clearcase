/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCBranches extends ICCBranches {

	public static final String componentName = "ClearCase.CCBranches"; //$NON-NLS-1$

	public CCBranches() {
		super(componentName);
	}

	public CCBranches(Dispatch d) {
		super(d);
	}
}
