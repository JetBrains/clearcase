/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCTriggerTypeBuilder extends Dispatch {

	public static final String componentName = "ClearCase.ICCTriggerTypeBuilder"; //$NON-NLS-1$

	public ICCTriggerTypeBuilder() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCTriggerTypeBuilder(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCTriggerTypeBuilder(String compName) {
		super(compName);
	}

	public String getName() {
		return Dispatch.get(this, "Name").toString(); //$NON-NLS-1$
	}

	public void setName(String lastParam) {
		Dispatch.put(this, "Name", lastParam); //$NON-NLS-1$
	}

	public Variant getActionsArray() {
		return Dispatch.get(this, "ActionsArray"); //$NON-NLS-1$
	}

	public void addExecAction(String lastParam) {
		Dispatch.call(this, "AddExecAction", lastParam); //$NON-NLS-1$
	}

	public void addExecUNIXAction(String lastParam) {
		Dispatch.call(this, "AddExecUNIXAction", lastParam); //$NON-NLS-1$
	}

	public void addExecWinAction(String lastParam) {
		Dispatch.call(this, "AddExecWinAction", lastParam); //$NON-NLS-1$
	}

	public void addMkattrAction(ICCAttributeType pAttributeType, Variant lastParam) {
		Dispatch.call(this, "AddMkattrAction", pAttributeType, lastParam); //$NON-NLS-1$
	}

	public void addMkhlinkFromAction(ICCHyperlinkType pHyperlinkType, String lastParam) {
		Dispatch.call(this, "AddMkhlinkFromAction", pHyperlinkType, lastParam); //$NON-NLS-1$
	}

	public void addMkhlinkToAction(ICCHyperlinkType pHyperlinkType, String lastParam) {
		Dispatch.call(this, "AddMkhlinkToAction", pHyperlinkType, lastParam); //$NON-NLS-1$
	}

	public void addMklabelAction(ICCLabelType lastParam) {
		Dispatch.call(this, "AddMklabelAction", lastParam); //$NON-NLS-1$
	}

	public ICCTriggerType create(String lastParam) {
		return new ICCTriggerType(Dispatch.call(this, "Create", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCTriggerType create() {
		return new ICCTriggerType(Dispatch.call(this, "Create").toDispatch()); //$NON-NLS-1$
	}

	public boolean getDebugPrinting() {
		return Dispatch.get(this, "DebugPrinting").toBoolean(); //$NON-NLS-1$
	}

	public void setDebugPrinting(boolean lastParam) {
		Dispatch.put(this, "DebugPrinting", new Variant(lastParam)); //$NON-NLS-1$
	}

	public Variant getExemptUsersStringArray() {
		return Dispatch.get(this, "ExemptUsersStringArray"); //$NON-NLS-1$
	}

	public void setExemptUsersStringArray(Variant lastParam) {
		Dispatch.put(this, "ExemptUsersStringArray", lastParam); //$NON-NLS-1$
	}

	public void fireOn(int lastParam) {
		Dispatch.call(this, "FireOn", new Variant(lastParam)); //$NON-NLS-1$
	}

	public int getFiring() {
		return Dispatch.get(this, "Firing").toInt(); //$NON-NLS-1$
	}

	public void setFiring(int lastParam) {
		Dispatch.put(this, "Firing", new Variant(lastParam)); //$NON-NLS-1$
	}

	public void includeOn(Variant lastParam) {
		Dispatch.call(this, "IncludeOn", lastParam); //$NON-NLS-1$
	}

	public Variant getInclusionsArray() {
		return Dispatch.get(this, "InclusionsArray"); //$NON-NLS-1$
	}

	public int getKindOfTrigger() {
		return Dispatch.get(this, "KindOfTrigger").toInt(); //$NON-NLS-1$
	}

	public void setKindOfTrigger(int lastParam) {
		Dispatch.put(this, "KindOfTrigger", new Variant(lastParam)); //$NON-NLS-1$
	}

	public int getNumberOfActions() {
		return Dispatch.get(this, "NumberOfActions").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfExemptUsers() {
		return Dispatch.get(this, "NumberOfExemptUsers").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfInclusions() {
		return Dispatch.get(this, "NumberOfInclusions").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfOperationKinds() {
		return Dispatch.get(this, "NumberOfOperationKinds").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfRestrictions() {
		return Dispatch.get(this, "NumberOfRestrictions").toInt(); //$NON-NLS-1$
	}

	public Variant getOperationKindsArray() {
		return Dispatch.get(this, "OperationKindsArray"); //$NON-NLS-1$
	}

	public void removeAction(int lastParam) {
		Dispatch.call(this, "RemoveAction", new Variant(lastParam)); //$NON-NLS-1$
	}

	public void removeInclusion(Variant lastParam) {
		Dispatch.call(this, "RemoveInclusion", lastParam); //$NON-NLS-1$
	}

	public void removeOperationKind(int lastParam) {
		Dispatch.call(this, "RemoveOperationKind", new Variant(lastParam)); //$NON-NLS-1$
	}

	public void removeRestriction(Variant lastParam) {
		Dispatch.call(this, "RemoveRestriction", lastParam); //$NON-NLS-1$
	}

	public ICCTriggerType replace(String lastParam) {
		return new ICCTriggerType(Dispatch.call(this, "Replace", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCTriggerType replace() {
		return new ICCTriggerType(Dispatch.call(this, "Replace").toDispatch()); //$NON-NLS-1$
	}

	public void restrictBy(Variant lastParam) {
		Dispatch.call(this, "RestrictBy", lastParam); //$NON-NLS-1$
	}

	public Variant getRestrictionsArray() {
		return Dispatch.get(this, "RestrictionsArray"); //$NON-NLS-1$
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch()); //$NON-NLS-1$
	}

}
