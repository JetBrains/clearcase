/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCBaseline extends ICCBaseline {

	public static final String componentName = "ClearCase.CCBaseline"; //$NON-NLS-1$

	public CCBaseline() {
		super(componentName);
	}

	public CCBaseline(Dispatch d) {
		super(d);
	}
}
