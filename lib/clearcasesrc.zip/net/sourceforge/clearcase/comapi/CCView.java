/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCView extends ICCView {

	public static final String componentName = "ClearCase.CCView"; //$NON-NLS-1$

	public CCView() {
		super(componentName);
	}

	public CCView(Dispatch d) {
		super(d);
	}
}
