/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCLabels extends ICCLabels {

	public static final String componentName = "ClearCase.CCLabels"; //$NON-NLS-1$

	public CCLabels() {
		super(componentName);
	}

	public CCLabels(Dispatch d) {
		super(d);
	}
}
