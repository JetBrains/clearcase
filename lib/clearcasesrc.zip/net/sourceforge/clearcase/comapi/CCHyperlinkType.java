/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCHyperlinkType extends ICCHyperlinkType {

	public static final String componentName = "ClearCase.CCHyperlinkType"; //$NON-NLS-1$

	public CCHyperlinkType() {
		super(componentName);
	}

	public CCHyperlinkType(Dispatch d) {
		super(d);
	}
}
