/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCTypeConstraint {

	public static final int ccConstraint_None = 0;
	public static final int ccConstraint_PerElement = 1;
	public static final int ccConstraint_PerBranch = 2;
	public static final int ccConstraint_PerVersion = 3;
}
