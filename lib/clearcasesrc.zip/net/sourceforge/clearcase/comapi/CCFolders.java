/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCFolders extends ICCFolders {

	public static final String componentName = "ClearCase.CCFolders"; //$NON-NLS-1$

	public CCFolders() {
		super(componentName);
	}

	public CCFolders(Dispatch d) {
		super(d);
	}
}
