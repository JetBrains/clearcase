/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class ClearTool extends IClearTool {

	public static final String componentName = "ClearCase.ClearTool"; //$NON-NLS-1$

	public ClearTool() {
		super(componentName);
	}

	public ClearTool(Dispatch d) {
		super(d);
	}
}
