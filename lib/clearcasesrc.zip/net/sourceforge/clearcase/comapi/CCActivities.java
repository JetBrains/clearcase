/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCActivities extends ICCActivities {

	public static final String componentName = "ClearCase.CCActivities"; //$NON-NLS-1$

	public CCActivities() {
		super(componentName);
	}

	public CCActivities(Dispatch d) {
		super(d);
	}
}
