/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCBranchType extends ICCBranchType {

	public static final String componentName = "ClearCase.CCBranchType"; //$NON-NLS-1$

	public CCBranchType() {
		super(componentName);
	}

	public CCBranchType(Dispatch d) {
		super(d);
	}
}
