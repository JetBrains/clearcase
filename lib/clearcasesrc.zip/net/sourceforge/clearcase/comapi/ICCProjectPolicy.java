/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCProjectPolicy extends Dispatch {

	public static final String componentName = "ClearCase.ICCProjectPolicy"; //$NON-NLS-1$

	public ICCProjectPolicy() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCProjectPolicy(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCProjectPolicy(String compName) {
		super(compName);
	}

	public boolean getDeliverRequireCheckin() {
		return Dispatch.get(this, "DeliverRequireCheckin").toBoolean(); //$NON-NLS-1$
	}

	public void setDeliverRequireCheckin(boolean lastParam) {
		Dispatch.put(this, "DeliverRequireCheckin", new Variant(lastParam)); //$NON-NLS-1$
	}

	public boolean getDeliverRequireRebase() {
		return Dispatch.get(this, "DeliverRequireRebase").toBoolean(); //$NON-NLS-1$
	}

	public void setDeliverRequireRebase(boolean lastParam) {
		Dispatch.put(this, "DeliverRequireRebase", new Variant(lastParam)); //$NON-NLS-1$
	}

	public boolean getUNIXDevelopmentSnapshot() {
		return Dispatch.get(this, "UNIXDevelopmentSnapshot").toBoolean(); //$NON-NLS-1$
	}

	public void setUNIXDevelopmentSnapshot(boolean lastParam) {
		Dispatch.put(this, "UNIXDevelopmentSnapshot", new Variant(lastParam)); //$NON-NLS-1$
	}

	public boolean getUNIXIntegrationSnapshot() {
		return Dispatch.get(this, "UNIXIntegrationSnapshot").toBoolean(); //$NON-NLS-1$
	}

	public void setUNIXIntegrationSnapshot(boolean lastParam) {
		Dispatch.put(this, "UNIXIntegrationSnapshot", new Variant(lastParam)); //$NON-NLS-1$
	}

	public boolean getWinDevelopmentSnapshot() {
		return Dispatch.get(this, "WinDevelopmentSnapshot").toBoolean(); //$NON-NLS-1$
	}

	public void setWinDevelopmentSnapshot(boolean lastParam) {
		Dispatch.put(this, "WinDevelopmentSnapshot", new Variant(lastParam)); //$NON-NLS-1$
	}

	public boolean getWinIntegrationSnapshot() {
		return Dispatch.get(this, "WinIntegrationSnapshot").toBoolean(); //$NON-NLS-1$
	}

	public void setWinIntegrationSnapshot(boolean lastParam) {
		Dispatch.put(this, "WinIntegrationSnapshot", new Variant(lastParam)); //$NON-NLS-1$
	}

}
