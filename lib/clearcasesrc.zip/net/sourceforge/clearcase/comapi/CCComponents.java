/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCComponents extends ICCComponents {

	public static final String componentName = "ClearCase.CCComponents"; //$NON-NLS-1$

	public CCComponents() {
		super(componentName);
	}

	public CCComponents(Dispatch d) {
		super(d);
	}
}
