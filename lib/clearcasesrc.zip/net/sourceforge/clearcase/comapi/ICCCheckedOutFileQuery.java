/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCCheckedOutFileQuery extends Dispatch {

	public static final String componentName = "ClearCase.ICCCheckedOutFileQuery"; //$NON-NLS-1$

	public ICCCheckedOutFileQuery() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCCheckedOutFileQuery(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCCheckedOutFileQuery(String compName) {
		super(compName);
	}

	public ICCCheckedOutFiles apply() {
		return new ICCCheckedOutFiles(Dispatch.call(this, "Apply").toDispatch()); //$NON-NLS-1$
	}

	public String getBranchType() {
		return Dispatch.get(this, "BranchType").toString(); //$NON-NLS-1$
	}

	public void setBranchType(String lastParam) {
		Dispatch.put(this, "BranchType", lastParam); //$NON-NLS-1$
	}

	public boolean getExamineAllReplicas() {
		return Dispatch.get(this, "ExamineAllReplicas").toBoolean(); //$NON-NLS-1$
	}

	public void setExamineAllReplicas(boolean lastParam) {
		Dispatch.put(this, "ExamineAllReplicas", new Variant(lastParam)); //$NON-NLS-1$
	}

	public Variant getPathArray() {
		return Dispatch.get(this, "PathArray"); //$NON-NLS-1$
	}

	public void setPathArray(Variant lastParam) {
		Dispatch.put(this, "PathArray", lastParam); //$NON-NLS-1$
	}

	public int getPathSelects() {
		return Dispatch.get(this, "PathSelects").toInt(); //$NON-NLS-1$
	}

	public void setPathSelects(int lastParam) {
		Dispatch.put(this, "PathSelects", new Variant(lastParam)); //$NON-NLS-1$
	}

	public boolean getUseCurrentView() {
		return Dispatch.get(this, "UseCurrentView").toBoolean(); //$NON-NLS-1$
	}

	public void setUseCurrentView(boolean lastParam) {
		Dispatch.put(this, "UseCurrentView", new Variant(lastParam)); //$NON-NLS-1$
	}

	public String getUser() {
		return Dispatch.get(this, "User").toString(); //$NON-NLS-1$
	}

	public void setUser(String lastParam) {
		Dispatch.put(this, "User", lastParam); //$NON-NLS-1$
	}

}
