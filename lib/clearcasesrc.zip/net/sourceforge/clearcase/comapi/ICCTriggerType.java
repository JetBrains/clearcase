/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCTriggerType extends Dispatch {

	public static final String componentName = "ClearCase.ICCTriggerType"; //$NON-NLS-1$

	public ICCTriggerType() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCTriggerType(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCTriggerType(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch()); //$NON-NLS-1$
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString(); //$NON-NLS-1$
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam); //$NON-NLS-1$
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch()); //$NON-NLS-1$
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString(); //$NON-NLS-1$
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString(); //$NON-NLS-1$
	}

	public String getName() {
		return Dispatch.get(this, "Name").toString(); //$NON-NLS-1$
	}

	public Variant getActionsArray() {
		return Dispatch.get(this, "ActionsArray"); //$NON-NLS-1$
	}

	public void apply(ICCElement pElement, String comment, boolean force, boolean recurse, Variant lastParam) {
		Dispatch.call(this, "Apply", pElement, comment, new Variant(force), new Variant(recurse), lastParam); //$NON-NLS-1$
	}

	public void apply(ICCElement pElement, String comment, boolean force, boolean recurse) {
		Dispatch.call(this, "Apply", pElement, comment, new Variant(force), new Variant(recurse)); //$NON-NLS-1$
	}

	public void apply(ICCElement pElement, String comment, boolean force) {
		Dispatch.call(this, "Apply", pElement, comment, new Variant(force)); //$NON-NLS-1$
	}

	public void apply(ICCElement pElement, String comment) {
		Dispatch.call(this, "Apply", pElement, comment); //$NON-NLS-1$
	}

	public void apply(ICCElement pElement) {
		Dispatch.call(this, "Apply", pElement); //$NON-NLS-1$
	}

	public ICCTriggerTypeBuilder createBuilderFromType() {
		return new ICCTriggerTypeBuilder(Dispatch.call(this, "CreateBuilderFromType").toDispatch()); //$NON-NLS-1$
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam); //$NON-NLS-1$
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete)); //$NON-NLS-1$
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment); //$NON-NLS-1$
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock"); //$NON-NLS-1$
	}

	public Variant getExemptUsersStringArray() {
		return Dispatch.get(this, "ExemptUsersStringArray"); //$NON-NLS-1$
	}

	public int getFiring() {
		return Dispatch.get(this, "Firing").toInt(); //$NON-NLS-1$
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString(); //$NON-NLS-1$
	}

	public Variant getInclusionsArray() {
		return Dispatch.get(this, "InclusionsArray"); //$NON-NLS-1$
	}

	public int getKindOfTrigger() {
		return Dispatch.get(this, "KindOfTrigger").toInt(); //$NON-NLS-1$
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch()); //$NON-NLS-1$
	}

	public int getNumberOfActions() {
		return Dispatch.get(this, "NumberOfActions").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfExemptUsers() {
		return Dispatch.get(this, "NumberOfExemptUsers").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfInclusions() {
		return Dispatch.get(this, "NumberOfInclusions").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfOperationKinds() {
		return Dispatch.get(this, "NumberOfOperationKinds").toInt(); //$NON-NLS-1$
	}

	public int getNumberOfRestrictions() {
		return Dispatch.get(this, "NumberOfRestrictions").toInt(); //$NON-NLS-1$
	}

	public Variant getOperationKindsArray() {
		return Dispatch.get(this, "OperationKindsArray"); //$NON-NLS-1$
	}

	public String getOwner() {
		return Dispatch.get(this, "Owner").toString(); //$NON-NLS-1$
	}

	public boolean getDebugPrinting() {
		return Dispatch.get(this, "DebugPrinting").toBoolean(); //$NON-NLS-1$
	}

	public void removeType(boolean removeAllInstances, boolean ignorePreopTriggers, String lastParam) {
		Dispatch.call(this, "RemoveType", new Variant(removeAllInstances), new Variant(ignorePreopTriggers), lastParam); //$NON-NLS-1$
	}

	public void removeType(boolean removeAllInstances, boolean ignorePreopTriggers) {
		Dispatch.call(this, "RemoveType", new Variant(removeAllInstances), new Variant(ignorePreopTriggers)); //$NON-NLS-1$
	}

	public void removeType(boolean removeAllInstances) {
		Dispatch.call(this, "RemoveType", new Variant(removeAllInstances)); //$NON-NLS-1$
	}

	public void removeType() {
		Dispatch.call(this, "RemoveType"); //$NON-NLS-1$
	}

	public Variant getRestrictionsArray() {
		return Dispatch.get(this, "RestrictionsArray"); //$NON-NLS-1$
	}

	public void setExemptUsersStringArray(Variant exemptUsersStringArray, String lastParam) {
		Dispatch.call(this, "SetExemptUsersStringArray", exemptUsersStringArray, lastParam); //$NON-NLS-1$
	}

	public void setExemptUsersStringArray(Variant exemptUsersStringArray) {
		Dispatch.call(this, "SetExemptUsersStringArray", exemptUsersStringArray); //$NON-NLS-1$
	}

	public void setExemptUsersStringArray() {
		Dispatch.call(this, "SetExemptUsersStringArray"); //$NON-NLS-1$
	}

	public void setGroup(String newGroup, String lastParam) {
		Dispatch.call(this, "SetGroup", newGroup, lastParam); //$NON-NLS-1$
	}

	public void setGroup(String newGroup) {
		Dispatch.call(this, "SetGroup", newGroup); //$NON-NLS-1$
	}

	public void setName(String newName, String lastParam) {
		Dispatch.call(this, "SetName", newName, lastParam); //$NON-NLS-1$
	}

	public void setName(String newName) {
		Dispatch.call(this, "SetName", newName); //$NON-NLS-1$
	}

	public void setOwner(String newOwner, String lastParam) {
		Dispatch.call(this, "SetOwner", newOwner, lastParam); //$NON-NLS-1$
	}

	public void setOwner(String newOwner) {
		Dispatch.call(this, "SetOwner", newOwner); //$NON-NLS-1$
	}

	public void setDebugPrinting(boolean newDebugPrinting, String lastParam) {
		Dispatch.call(this, "SetDebugPrinting", new Variant(newDebugPrinting), lastParam); //$NON-NLS-1$
	}

	public void setDebugPrinting(boolean newDebugPrinting) {
		Dispatch.call(this, "SetDebugPrinting", new Variant(newDebugPrinting)); //$NON-NLS-1$
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch()); //$NON-NLS-1$
	}

}
