/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCBranch extends Dispatch {

	public static final String componentName = "ClearCase.ICCBranch"; //$NON-NLS-1$

	public ICCBranch() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCBranch(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCBranch(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch()); //$NON-NLS-1$
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString(); //$NON-NLS-1$
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam); //$NON-NLS-1$
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch()); //$NON-NLS-1$
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString(); //$NON-NLS-1$
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString(); //$NON-NLS-1$
	}

	public String getPath() {
		return Dispatch.get(this, "Path").toString(); //$NON-NLS-1$
	}

	public ICCVersion getBranchPointVersion() {
		return new ICCVersion(Dispatch.get(this, "BranchPointVersion").toDispatch()); //$NON-NLS-1$
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam); //$NON-NLS-1$
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete)); //$NON-NLS-1$
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment); //$NON-NLS-1$
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock"); //$NON-NLS-1$
	}

	public ICCElement getElement() {
		return new ICCElement(Dispatch.get(this, "Element").toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion getLatestVersion() {
		return new ICCVersion(Dispatch.get(this, "LatestVersion").toDispatch()); //$NON-NLS-1$
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch()); //$NON-NLS-1$
	}

	public String getMaster() {
		return Dispatch.get(this, "Master").toString(); //$NON-NLS-1$
	}

	public void remove(String lastParam) {
		Dispatch.call(this, "Remove", lastParam); //$NON-NLS-1$
	}

	public void remove() {
		Dispatch.call(this, "Remove"); //$NON-NLS-1$
	}

	public void requestMaster(String lastParam) {
		Dispatch.call(this, "RequestMaster", lastParam); //$NON-NLS-1$
	}

	public void requestMaster() {
		Dispatch.call(this, "RequestMaster"); //$NON-NLS-1$
	}

	public void setMaster(String replica, String lastParam) {
		Dispatch.call(this, "SetMaster", replica, lastParam); //$NON-NLS-1$
	}

	public void setMaster(String replica) {
		Dispatch.call(this, "SetMaster", replica); //$NON-NLS-1$
	}

	public ICCBranchType getType() {
		return new ICCBranchType(Dispatch.get(this, "Type").toDispatch()); //$NON-NLS-1$
	}

	public ICCVersions getVersions() {
		return new ICCVersions(Dispatch.get(this, "Versions").toDispatch()); //$NON-NLS-1$
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch()); //$NON-NLS-1$
	}

}
