/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCLabelStatus {

	public static final int ccLabelStatus_Unlabeled = 0;
	public static final int ccLabelStatus_Incremental = 1;
	public static final int ccLabelStatus_Full = 2;
}
