/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCVOBs extends ICCVOBs {

	public static final String componentName = "ClearCase.CCVOBs"; //$NON-NLS-1$

	public CCVOBs() {
		super(componentName);
	}

	public CCVOBs(Dispatch d) {
		super(d);
	}
}
