/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCComponent extends ICCComponent {

	public static final String componentName = "ClearCase.CCComponent"; //$NON-NLS-1$

	public CCComponent() {
		super(componentName);
	}

	public CCComponent(Dispatch d) {
		super(d);
	}
}
