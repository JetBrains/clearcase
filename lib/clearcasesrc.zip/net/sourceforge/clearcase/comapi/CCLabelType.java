/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCLabelType extends ICCLabelType {

	public static final String componentName = "ClearCase.CCLabelType"; //$NON-NLS-1$

	public CCLabelType() {
		super(componentName);
	}

	public CCLabelType(Dispatch d) {
		super(d);
	}
}
