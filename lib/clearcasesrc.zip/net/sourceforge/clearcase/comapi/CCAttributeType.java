/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCAttributeType extends ICCAttributeType {

	public static final String componentName = "ClearCase.CCAttributeType"; //$NON-NLS-1$

	public CCAttributeType() {
		super(componentName);
	}

	public CCAttributeType(Dispatch d) {
		super(d);
	}
}
