/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCHistoryRecords extends ICCHistoryRecords {

	public static final String componentName = "ClearCase.CCHistoryRecords"; //$NON-NLS-1$

	public CCHistoryRecords() {
		super(componentName);
	}

	public CCHistoryRecords(Dispatch d) {
		super(d);
	}
}
