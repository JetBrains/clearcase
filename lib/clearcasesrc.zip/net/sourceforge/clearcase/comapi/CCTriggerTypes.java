/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCTriggerTypes extends ICCTriggerTypes {

	public static final String componentName = "ClearCase.CCTriggerTypes"; //$NON-NLS-1$

	public CCTriggerTypes() {
		super(componentName);
	}

	public CCTriggerTypes(Dispatch d) {
		super(d);
	}
}
