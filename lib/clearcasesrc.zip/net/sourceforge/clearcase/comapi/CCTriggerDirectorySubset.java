/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCTriggerDirectorySubset {

	public static final int ccSubset_Both = 0;
	public static final int ccSubset_NotInheritance = 1;
	public static final int ccSubset_NotAttached = 2;
}
