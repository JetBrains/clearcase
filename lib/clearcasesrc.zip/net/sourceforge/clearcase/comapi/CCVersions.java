/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCVersions extends ICCVersions {

	public static final String componentName = "ClearCase.CCVersions"; //$NON-NLS-1$

	public CCVersions() {
		super(componentName);
	}

	public CCVersions(Dispatch d) {
		super(d);
	}
}
