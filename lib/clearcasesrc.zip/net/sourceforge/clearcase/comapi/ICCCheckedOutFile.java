/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCCheckedOutFile extends Dispatch {

	public static final String componentName = "ClearCase.ICCCheckedOutFile"; //$NON-NLS-1$

	public ICCCheckedOutFile() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCCheckedOutFile(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCCheckedOutFile(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch()); //$NON-NLS-1$
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString(); //$NON-NLS-1$
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam); //$NON-NLS-1$
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch()); //$NON-NLS-1$
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString(); //$NON-NLS-1$
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString(); //$NON-NLS-1$
	}

	public String getPath() {
		return Dispatch.get(this, "Path").toString(); //$NON-NLS-1$
	}

	public String getExtendedPath() {
		return Dispatch.get(this, "ExtendedPath").toString(); //$NON-NLS-1$
	}

	public String getExtendedPathInView(ICCView lastParam) {
		return Dispatch.call(this, "ExtendedPathInView", lastParam).toString(); //$NON-NLS-1$
	}

	public boolean getIsDirectory() {
		return Dispatch.get(this, "IsDirectory").toBoolean(); //$NON-NLS-1$
	}

	public String getPathInView(ICCView lastParam) {
		return Dispatch.call(this, "PathInView", lastParam).toString(); //$NON-NLS-1$
	}

	public ICCView getView() {
		return new ICCView(Dispatch.get(this, "View").toDispatch()); //$NON-NLS-1$
	}

	public ICCVOB getVOB() {
		return new ICCVOB(Dispatch.get(this, "VOB").toDispatch()); //$NON-NLS-1$
	}

	public ICCBranch getBranch() {
		return new ICCBranch(Dispatch.get(this, "Branch").toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment, boolean useHijacked, int version, boolean mustBeLatest, boolean lastParam) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment, new Variant(useHijacked), new Variant(version), new Variant(mustBeLatest), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment, boolean useHijacked, int version, boolean mustBeLatest) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment, new Variant(useHijacked), new Variant(version), new Variant(mustBeLatest)).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment, boolean useHijacked, int version) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment, new Variant(useHijacked), new Variant(version)).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment, boolean useHijacked) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment, new Variant(useHijacked)).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile checkOut(int reservedState, String comment) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState), comment).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile checkOut(int reservedState) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckOut", new Variant(reservedState)).toDispatch()); //$NON-NLS-1$
	}

	public ICCElement getElement() {
		return new ICCElement(Dispatch.get(this, "Element").toDispatch()); //$NON-NLS-1$
	}

	public String getIdentifier() {
		return Dispatch.get(this, "Identifier").toString(); //$NON-NLS-1$
	}

	public boolean getIsCheckedOut() {
		return Dispatch.get(this, "IsCheckedOut").toBoolean(); //$NON-NLS-1$
	}

	public boolean getIsDifferent() {
		return Dispatch.get(this, "IsDifferent").toBoolean(); //$NON-NLS-1$
	}

	public boolean getIsHijacked() {
		return Dispatch.get(this, "IsHijacked").toBoolean(); //$NON-NLS-1$
	}

	public boolean getIsLatest() {
		return Dispatch.get(this, "IsLatest").toBoolean(); //$NON-NLS-1$
	}

	public ICCLabel getLabel(String lastParam) {
		return new ICCLabel(Dispatch.call(this, "Label", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCLabels getLabels() {
		return new ICCLabels(Dispatch.get(this, "Labels").toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion getParent() {
		return new ICCVersion(Dispatch.get(this, "Parent").toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion getPredecessor() {
		return new ICCVersion(Dispatch.get(this, "Predecessor").toDispatch()); //$NON-NLS-1$
	}

	public void removeVersion(String comment, boolean dataOnly, boolean evenIfBranches, boolean evenIfLabels, boolean evenIfAttributes, boolean lastParam) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly), new Variant(evenIfBranches), new Variant(evenIfLabels), new Variant(evenIfAttributes), new Variant(lastParam)); //$NON-NLS-1$
	}

	public void removeVersion(String comment, boolean dataOnly, boolean evenIfBranches, boolean evenIfLabels, boolean evenIfAttributes) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly), new Variant(evenIfBranches), new Variant(evenIfLabels), new Variant(evenIfAttributes)); //$NON-NLS-1$
	}

	public void removeVersion(String comment, boolean dataOnly, boolean evenIfBranches, boolean evenIfLabels) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly), new Variant(evenIfBranches), new Variant(evenIfLabels)); //$NON-NLS-1$
	}

	public void removeVersion(String comment, boolean dataOnly, boolean evenIfBranches) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly), new Variant(evenIfBranches)); //$NON-NLS-1$
	}

	public void removeVersion(String comment, boolean dataOnly) {
		Dispatch.call(this, "RemoveVersion", comment, new Variant(dataOnly)); //$NON-NLS-1$
	}

	public void removeVersion(String comment) {
		Dispatch.call(this, "RemoveVersion", comment); //$NON-NLS-1$
	}

	public void removeVersion() {
		Dispatch.call(this, "RemoveVersion"); //$NON-NLS-1$
	}

	public ICCBranches getSubBranches() {
		return new ICCBranches(Dispatch.get(this, "SubBranches").toDispatch()); //$NON-NLS-1$
	}

	public int getVersionNumber() {
		return Dispatch.get(this, "VersionNumber").toInt(); //$NON-NLS-1$
	}

	public ICCView getByView() {
		return new ICCView(Dispatch.get(this, "ByView").toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion checkIn(String comment, boolean evenIfIdentical, String fromPath, int lastParam) {
		return new ICCVersion(Dispatch.call(this, "CheckIn", comment, new Variant(evenIfIdentical), fromPath, new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion checkIn(String comment, boolean evenIfIdentical, String fromPath) {
		return new ICCVersion(Dispatch.call(this, "CheckIn", comment, new Variant(evenIfIdentical), fromPath).toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion checkIn(String comment, boolean evenIfIdentical) {
		return new ICCVersion(Dispatch.call(this, "CheckIn", comment, new Variant(evenIfIdentical)).toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion checkIn(String comment) {
		return new ICCVersion(Dispatch.call(this, "CheckIn", comment).toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion checkIn() {
		return new ICCVersion(Dispatch.call(this, "CheckIn").toDispatch()); //$NON-NLS-1$
	}

	public boolean getIsReserved() {
		return Dispatch.get(this, "IsReserved").toBoolean(); //$NON-NLS-1$
	}

	public void reserve(String lastParam) {
		Dispatch.call(this, "Reserve", lastParam); //$NON-NLS-1$
	}

	public void reserve() {
		Dispatch.call(this, "Reserve"); //$NON-NLS-1$
	}

	public ICCVersion unCheckOut(int lastParam) {
		return new ICCVersion(Dispatch.call(this, "UnCheckOut", new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public void unReserve(String lastParam) {
		Dispatch.call(this, "UnReserve", lastParam); //$NON-NLS-1$
	}

	public void unReserve() {
		Dispatch.call(this, "UnReserve"); //$NON-NLS-1$
	}

}
