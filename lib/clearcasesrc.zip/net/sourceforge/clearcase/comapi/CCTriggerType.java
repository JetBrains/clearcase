/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCTriggerType extends ICCTriggerType {

	public static final String componentName = "ClearCase.CCTriggerType"; //$NON-NLS-1$

	public CCTriggerType() {
		super(componentName);
	}

	public CCTriggerType(Dispatch d) {
		super(d);
	}
}
