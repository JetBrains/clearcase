/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;


public interface CCReservedState {

	public static final int ccReserved = 0;
	public static final int ccUnreserved = 1;
	public static final int ccTryReserved = 2;
}
