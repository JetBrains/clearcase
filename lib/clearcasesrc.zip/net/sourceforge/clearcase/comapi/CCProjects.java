/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCProjects extends ICCProjects {

	public static final String componentName = "ClearCase.CCProjects"; //$NON-NLS-1$

	public CCProjects() {
		super(componentName);
	}

	public CCProjects(Dispatch d) {
		super(d);
	}
}
