/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class IClearCase extends Dispatch {

	public static final String componentName = "ClearCase.IClearCase"; //$NON-NLS-1$

	public IClearCase() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public IClearCase(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public IClearCase(String compName) {
		super(compName);
	}

	public ICCActivity getActivity(String lastParam) {
		return new ICCActivity(Dispatch.call(this, "Activity", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributes getAttributesEmpty() {
		return new ICCAttributes(Dispatch.get(this, "AttributesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributeTypes getAttributeTypesEmpty() {
		return new ICCAttributeTypes(Dispatch.get(this, "AttributeTypesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCBranches getBranchesEmpty() {
		return new ICCBranches(Dispatch.get(this, "BranchesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCBranchTypes getBranchTypesEmpty() {
		return new ICCBranchTypes(Dispatch.get(this, "BranchTypesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile getCheckedOutFile(String lastParam) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CheckedOutFile", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFiles getCheckedOutFilesEmpty() {
		return new ICCCheckedOutFiles(Dispatch.get(this, "CheckedOutFilesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public void checkLicense() {
		Dispatch.call(this, "CheckLicense"); //$NON-NLS-1$
	}

	public ICCCheckedOutFileQuery createCheckedOutFileQuery() {
		return new ICCCheckedOutFileQuery(Dispatch.call(this, "CreateCheckedOutFileQuery").toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile createElement(String path, String comment, boolean setMaster, Variant lastParam) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CreateElement", path, comment, new Variant(setMaster), lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile createElement(String path, String comment, boolean setMaster) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CreateElement", path, comment, new Variant(setMaster)).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile createElement(String path, String comment) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CreateElement", path, comment).toDispatch()); //$NON-NLS-1$
	}

	public ICCCheckedOutFile createElement(String path) {
		return new ICCCheckedOutFile(Dispatch.call(this, "CreateElement", path).toDispatch()); //$NON-NLS-1$
	}

	public ICCElement getElement(String lastParam) {
		return new ICCElement(Dispatch.call(this, "Element", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCElements getElementsEmpty() {
		return new ICCElements(Dispatch.get(this, "ElementsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecordsEmpty() {
		return new ICCHistoryRecords(Dispatch.get(this, "HistoryRecordsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlink getHyperlink(String lastParam) {
		return new ICCHyperlink(Dispatch.call(this, "Hyperlink", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinksEmpty() {
		return new ICCHyperlinks(Dispatch.get(this, "HyperlinksEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinkTypes getHyperlinkTypesEmpty() {
		return new ICCHyperlinkTypes(Dispatch.get(this, "HyperlinkTypesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public void setIsWebGUI(boolean lastParam) {
		Dispatch.put(this, "IsWebGUI", new Variant(lastParam)); //$NON-NLS-1$
	}

	public ICCLabels getLabelsEmpty() {
		return new ICCLabels(Dispatch.get(this, "LabelsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCLabelTypes getLabelTypesEmpty() {
		return new ICCLabelTypes(Dispatch.get(this, "LabelTypesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCLocks getLocksEmpty() {
		return new ICCLocks(Dispatch.get(this, "LocksEmpty").toDispatch()); //$NON-NLS-1$
	}

	public void setAbortPrompts() {
		Dispatch.call(this, "SetAbortPrompts"); //$NON-NLS-1$
	}

	public ICCTriggers getTriggersEmpty() {
		return new ICCTriggers(Dispatch.get(this, "TriggersEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCTriggerTypes getTriggerTypesEmpty() {
		return new ICCTriggerTypes(Dispatch.get(this, "TriggerTypesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCVersion getVersion(Variant lastParam) {
		return new ICCVersion(Dispatch.call(this, "Version", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCVersions getVersionsEmpty() {
		return new ICCVersions(Dispatch.get(this, "VersionsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCView getView(String lastParam) {
		return new ICCView(Dispatch.call(this, "View", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCView getView() {
		return new ICCView(Dispatch.get(this, "View").toDispatch()); //$NON-NLS-1$
	}

	public ICCViews getViews(boolean failIfErrors, String lastParam) {
		return new ICCViews(Dispatch.call(this, "Views", new Variant(failIfErrors), lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCViews getViews(boolean failIfErrors) {
		return new ICCViews(Dispatch.call(this, "Views", new Variant(failIfErrors)).toDispatch()); //$NON-NLS-1$
	}

	public ICCViews getViews() {
		return new ICCViews(Dispatch.get(this, "Views").toDispatch()); //$NON-NLS-1$
	}

	public ICCViews getViewsEmpty() {
		return new ICCViews(Dispatch.get(this, "ViewsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCVOB getVOB(String lastParam) {
		return new ICCVOB(Dispatch.call(this, "VOB", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCVOBs getVOBs(boolean failIfErrors, String lastParam) {
		return new ICCVOBs(Dispatch.call(this, "VOBs", new Variant(failIfErrors), lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCVOBs getVOBs(boolean failIfErrors) {
		return new ICCVOBs(Dispatch.call(this, "VOBs", new Variant(failIfErrors)).toDispatch()); //$NON-NLS-1$
	}

	public ICCVOBs getVOBs() {
		return new ICCVOBs(Dispatch.get(this, "VOBs").toDispatch()); //$NON-NLS-1$
	}

	public ICCVOBs getVOBsEmpty() {
		return new ICCVOBs(Dispatch.get(this, "VOBsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCActivities getActivitiesEmpty() {
		return new ICCActivities(Dispatch.get(this, "ActivitiesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCActivity getActivityOfVersion(ICCVersion lastParam) {
		return new ICCActivity(Dispatch.call(this, "ActivityOfVersion", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCBaseline getBaseline(String lastParam) {
		return new ICCBaseline(Dispatch.call(this, "Baseline", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCBaselines getBaselinesEmpty() {
		return new ICCBaselines(Dispatch.get(this, "BaselinesEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCComponent getComponent(String lastParam) {
		return new ICCComponent(Dispatch.call(this, "Component", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCComponents getComponentsEmpty() {
		return new ICCComponents(Dispatch.get(this, "ComponentsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCBaselineComparison createBaselineComparison() {
		return new ICCBaselineComparison(Dispatch.call(this, "CreateBaselineComparison").toDispatch()); //$NON-NLS-1$
	}

	public ICCFolder getFolder(String lastParam) {
		return new ICCFolder(Dispatch.call(this, "Folder", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCFolders getFoldersEmpty() {
		return new ICCFolders(Dispatch.get(this, "FoldersEmpty").toDispatch()); //$NON-NLS-1$
	}

	public boolean getIsClearCaseLT() {
		return Dispatch.get(this, "IsClearCaseLT").toBoolean(); //$NON-NLS-1$
	}

	public boolean getIsClearCaseLTClient() {
		return Dispatch.get(this, "IsClearCaseLTClient").toBoolean(); //$NON-NLS-1$
	}

	public boolean getIsClearCaseLTServer() {
		return Dispatch.get(this, "IsClearCaseLTServer").toBoolean(); //$NON-NLS-1$
	}

	public ICCProject getProject(String lastParam) {
		return new ICCProject(Dispatch.call(this, "Project", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCProjects getProjectsEmpty() {
		return new ICCProjects(Dispatch.get(this, "ProjectsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCProjectVOB getProjectVOB(String lastParam) {
		return new ICCProjectVOB(Dispatch.call(this, "ProjectVOB", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCProjectVOBs getProjectVOBsEmpty() {
		return new ICCProjectVOBs(Dispatch.get(this, "ProjectVOBsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public ICCStream getStream(String lastParam) {
		return new ICCStream(Dispatch.call(this, "Stream", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCStreams getStreamsEmpty() {
		return new ICCStreams(Dispatch.get(this, "StreamsEmpty").toDispatch()); //$NON-NLS-1$
	}

	public String getUniversalSelector(ICCVOBObject lastParam) {
		return Dispatch.call(this, "UniversalSelector", lastParam).toString(); //$NON-NLS-1$
	}

}
