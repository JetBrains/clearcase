/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCElement extends ICCElement {

	public static final String componentName = "ClearCase.CCElement"; //$NON-NLS-1$

	public CCElement() {
		super(componentName);
	}

	public CCElement(Dispatch d) {
		super(d);
	}
}
