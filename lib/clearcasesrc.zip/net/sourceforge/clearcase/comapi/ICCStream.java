/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCStream extends Dispatch {

	public static final String componentName = "ClearCase.ICCStream"; //$NON-NLS-1$

	public ICCStream() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCStream(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCStream(String compName) {
		super(compName);
	}

	public ICCAttribute getAttribute(String lastParam) {
		return new ICCAttribute(Dispatch.call(this, "Attribute", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCAttributes getAttributes() {
		return new ICCAttributes(Dispatch.get(this, "Attributes").toDispatch()); //$NON-NLS-1$
	}

	public String getComment() {
		return Dispatch.get(this, "Comment").toString(); //$NON-NLS-1$
	}

	public void setComment(String lastParam) {
		Dispatch.put(this, "Comment", lastParam); //$NON-NLS-1$
	}

	public ICCHistoryRecord getCreationRecord() {
		return new ICCHistoryRecord(Dispatch.get(this, "CreationRecord").toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse, boolean lastParam) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse), new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents, boolean recurse) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents), new Variant(recurse)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor, boolean excludeCheckOutEvents) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor), new Variant(excludeCheckOutEvents)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user, boolean minor) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user, new Variant(minor)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since, String user) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since), user).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType, java.util.Date since) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType, new Variant(since)).toDispatch()); //$NON-NLS-1$
	}

	public ICCHistoryRecords getHistoryRecords(ICCBranchType pICCBranchType) {
		return new ICCHistoryRecords(Dispatch.call(this, "HistoryRecords", pICCBranchType).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks(String lastParam) {
		return new ICCHyperlinks(Dispatch.call(this, "Hyperlinks", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCHyperlinks getHyperlinks() {
		return new ICCHyperlinks(Dispatch.get(this, "Hyperlinks").toDispatch()); //$NON-NLS-1$
	}

	public String getOID() {
		return Dispatch.get(this, "OID").toString(); //$NON-NLS-1$
	}

	public String getVOBFamilyUUID() {
		return Dispatch.get(this, "VOBFamilyUUID").toString(); //$NON-NLS-1$
	}

	public String getName() {
		return Dispatch.get(this, "Name").toString(); //$NON-NLS-1$
	}

	public void createLock(String comment, boolean obsolete, Variant lastParam) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete), lastParam); //$NON-NLS-1$
	}

	public void createLock(String comment, boolean obsolete) {
		Dispatch.call(this, "CreateLock", comment, new Variant(obsolete)); //$NON-NLS-1$
	}

	public void createLock(String comment) {
		Dispatch.call(this, "CreateLock", comment); //$NON-NLS-1$
	}

	public void createLock() {
		Dispatch.call(this, "CreateLock"); //$NON-NLS-1$
	}

	public String getGroup() {
		return Dispatch.get(this, "Group").toString(); //$NON-NLS-1$
	}

	public ICCLock getLock() {
		return new ICCLock(Dispatch.get(this, "Lock").toDispatch()); //$NON-NLS-1$
	}

	public String getMaster() {
		return Dispatch.get(this, "Master").toString(); //$NON-NLS-1$
	}

	public String getOwner() {
		return Dispatch.get(this, "Owner").toString(); //$NON-NLS-1$
	}

	public ICCProjectVOB getProjectVOB() {
		return new ICCProjectVOB(Dispatch.get(this, "ProjectVOB").toDispatch()); //$NON-NLS-1$
	}

	public void setGroup(String newGroup, String lastParam) {
		Dispatch.call(this, "SetGroup", newGroup, lastParam); //$NON-NLS-1$
	}

	public void setGroup(String newGroup) {
		Dispatch.call(this, "SetGroup", newGroup); //$NON-NLS-1$
	}

	public void setMaster(String replica, String lastParam) {
		Dispatch.call(this, "SetMaster", replica, lastParam); //$NON-NLS-1$
	}

	public void setMaster(String replica) {
		Dispatch.call(this, "SetMaster", replica); //$NON-NLS-1$
	}

	public void setOwner(String newOwner, String lastParam) {
		Dispatch.call(this, "SetOwner", newOwner, lastParam); //$NON-NLS-1$
	}

	public void setOwner(String newOwner) {
		Dispatch.call(this, "SetOwner", newOwner); //$NON-NLS-1$
	}

	public String getTitle() {
		return Dispatch.get(this, "Title").toString(); //$NON-NLS-1$
	}

	public ICCActivities getActivities() {
		return new ICCActivities(Dispatch.get(this, "Activities").toDispatch()); //$NON-NLS-1$
	}

	public ICCBaselines getBaselines(ICCComponent lastParam) {
		return new ICCBaselines(Dispatch.call(this, "Baselines", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCActivity createActivity(String headline, String comment, String lastParam) {
		return new ICCActivity(Dispatch.call(this, "CreateActivity", headline, comment, lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCActivity createActivity(String headline, String comment) {
		return new ICCActivity(Dispatch.call(this, "CreateActivity", headline, comment).toDispatch()); //$NON-NLS-1$
	}

	public ICCActivity createActivity(String headline) {
		return new ICCActivity(Dispatch.call(this, "CreateActivity", headline).toDispatch()); //$NON-NLS-1$
	}

	public ICCActivity createActivity() {
		return new ICCActivity(Dispatch.call(this, "CreateActivity").toDispatch()); //$NON-NLS-1$
	}

	public ICCBaseline getFoundationBaseline(ICCComponent lastParam) {
		return new ICCBaseline(Dispatch.call(this, "FoundationBaseline", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCBaselines getFoundationBaselines() {
		return new ICCBaselines(Dispatch.get(this, "FoundationBaselines").toDispatch()); //$NON-NLS-1$
	}

	public boolean getHasActivities() {
		return Dispatch.get(this, "HasActivities").toBoolean(); //$NON-NLS-1$
	}

	public boolean getIsIntegrationStream() {
		return Dispatch.get(this, "IsIntegrationStream").toBoolean(); //$NON-NLS-1$
	}

	public ICCBaseline getLatestBaseline(ICCComponent lastParam) {
		return new ICCBaseline(Dispatch.call(this, "LatestBaseline", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCBaselines getLatestBaselines() {
		return new ICCBaselines(Dispatch.get(this, "LatestBaselines").toDispatch()); //$NON-NLS-1$
	}

	public ICCProject getProject() {
		return new ICCProject(Dispatch.get(this, "Project").toDispatch()); //$NON-NLS-1$
	}

	public ICCViews getViews(String lastParam) {
		return new ICCViews(Dispatch.call(this, "Views", lastParam).toDispatch()); //$NON-NLS-1$
	}

	public ICCViews getViews() {
		return new ICCViews(Dispatch.get(this, "Views").toDispatch()); //$NON-NLS-1$
	}

}
