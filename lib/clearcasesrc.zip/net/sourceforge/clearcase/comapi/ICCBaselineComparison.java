/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class ICCBaselineComparison extends Dispatch {

	public static final String componentName = "ClearCase.ICCBaselineComparison"; //$NON-NLS-1$

	public ICCBaselineComparison() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCBaselineComparison(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCBaselineComparison(String compName) {
		super(compName);
	}

	public ICCActivities getActivitiesInOneButNotTwo() {
		return new ICCActivities(Dispatch.get(this, "ActivitiesInOneButNotTwo").toDispatch()); //$NON-NLS-1$
	}

	public ICCActivities getActivitiesInTwoButNotOne() {
		return new ICCActivities(Dispatch.get(this, "ActivitiesInTwoButNotOne").toDispatch()); //$NON-NLS-1$
	}

	public ICCBaseline getBaselineOne() {
		return new ICCBaseline(Dispatch.get(this, "BaselineOne").toDispatch()); //$NON-NLS-1$
	}

	public void setBaselineOne(ICCBaseline lastParam) {
		Dispatch.put(this, "BaselineOne", lastParam); //$NON-NLS-1$
	}

	public ICCBaseline getBaselineTwo() {
		return new ICCBaseline(Dispatch.get(this, "BaselineTwo").toDispatch()); //$NON-NLS-1$
	}

	public void setBaselineTwo(ICCBaseline lastParam) {
		Dispatch.put(this, "BaselineTwo", lastParam); //$NON-NLS-1$
	}

	public ICCActivities getChangedActivities() {
		return new ICCActivities(Dispatch.get(this, "ChangedActivities").toDispatch()); //$NON-NLS-1$
	}

	public void compare() {
		Dispatch.call(this, "Compare"); //$NON-NLS-1$
	}

	public ICCStream getStreamOne() {
		return new ICCStream(Dispatch.get(this, "StreamOne").toDispatch()); //$NON-NLS-1$
	}

	public void setStreamOne(ICCStream lastParam) {
		Dispatch.put(this, "StreamOne", lastParam); //$NON-NLS-1$
	}

	public ICCStream getStreamTwo() {
		return new ICCStream(Dispatch.get(this, "StreamTwo").toDispatch()); //$NON-NLS-1$
	}

	public void setStreamTwo(ICCStream lastParam) {
		Dispatch.put(this, "StreamTwo", lastParam); //$NON-NLS-1$
	}

	public ICCVersions getVersionsInOneButNotTwo() {
		return new ICCVersions(Dispatch.get(this, "VersionsInOneButNotTwo").toDispatch()); //$NON-NLS-1$
	}

	public ICCVersions getVersionsInTwoButNotOne() {
		return new ICCVersions(Dispatch.get(this, "VersionsInTwoButNotOne").toDispatch()); //$NON-NLS-1$
	}

}
