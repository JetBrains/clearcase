/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class CCCheckedOutFile extends ICCCheckedOutFile {

	public static final String componentName = "ClearCase.CCCheckedOutFile"; //$NON-NLS-1$

	public CCCheckedOutFile() {
		super(componentName);
	}

	public CCCheckedOutFile(Dispatch d) {
		super(d);
	}
}
