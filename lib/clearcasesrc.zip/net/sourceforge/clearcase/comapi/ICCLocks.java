/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCLocks extends Dispatch {

	public static final String componentName = "ClearCase.ICCLocks"; //$NON-NLS-1$

	public ICCLocks() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCLocks(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCLocks(String compName) {
		super(compName);
	}

	public ICCLock getItem(int lastParam) {
		return new ICCLock(Dispatch.call(this, "Item", new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public void add(ICCLock lastParam) {
		Dispatch.call(this, "Add", lastParam); //$NON-NLS-1$
	}

	public int getCount() {
		return Dispatch.get(this, "Count").toInt(); //$NON-NLS-1$
	}

	public void remove(int lastParam) {
		Dispatch.call(this, "Remove", new Variant(lastParam)); //$NON-NLS-1$
	}

	public Object get_NewEnum() {
		return Dispatch.get(this, "_NewEnum"); //$NON-NLS-1$
	}

}
