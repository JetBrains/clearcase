/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class ICCVersions extends Dispatch {

	public static final String componentName = "ClearCase.ICCVersions"; //$NON-NLS-1$

	public ICCVersions() {
		super(componentName);
	}

	/**
	* This constructor is used instead of a case operation to
	* turn a Dispatch object into a wider object - it must exist
	* in every wrapper class whose instances may be returned from
	* method calls wrapped in VT_DISPATCH Variants.
	*/
	public ICCVersions(Dispatch d) {
		// take over the IDispatch pointer
		m_pDispatch = d.m_pDispatch;
		// null out the input's pointer
		d.m_pDispatch = 0;
	}

	public ICCVersions(String compName) {
		super(compName);
	}

	public ICCVersion getItem(int lastParam) {
		return new ICCVersion(Dispatch.call(this, "Item", new Variant(lastParam)).toDispatch()); //$NON-NLS-1$
	}

	public void add(ICCVersion lastParam) {
		Dispatch.call(this, "Add", lastParam); //$NON-NLS-1$
	}

	public int getCount() {
		return Dispatch.get(this, "Count").toInt(); //$NON-NLS-1$
	}

	public void remove(int lastParam) {
		Dispatch.call(this, "Remove", new Variant(lastParam)); //$NON-NLS-1$
	}

	public String getInitErrors() {
		return Dispatch.get(this, "InitErrors").toString(); //$NON-NLS-1$
	}

	public Object get_NewEnum() {
		return Dispatch.get(this, "_NewEnum"); //$NON-NLS-1$
	}

}
