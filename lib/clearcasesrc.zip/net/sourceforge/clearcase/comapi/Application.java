/**
 * JacobGen generated file --- do not edit
 *
 * (http://www.bigatti.it/projects/jacobgen)
 */
package net.sourceforge.clearcase.comapi;

import com.jacob.com.Dispatch;

public class Application extends IClearCase {

	public static final String componentName = "ClearCase.Application"; //$NON-NLS-1$

	public Application() {
		super(componentName);
	}

	public Application(Dispatch d) {
		super(d);
	}
}
